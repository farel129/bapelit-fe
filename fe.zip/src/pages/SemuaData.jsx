import React, { useState, useEffect } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { FileText, TrendingUp, Clock, X, CheckCircle, Eye, Download, Calendar, User, Building2, MessageSquare, Database } from 'lucide-react';
import axios from 'axios';
import toast from 'react-hot-toast';
import { api } from '../utils/api';

const SemuaData = () => {
  const [suratData, setSuratData] = useState([]);
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [selectedSurat, setSelectedSurat] = useState(null);
  const [downloadProgress, setDownloadProgress] = useState(0);
  const [isDownloading, setIsDownloading] = useState(false);

  // Fetch data dari API
  useEffect(() => {
    fetchAllData();
  }, []);

  const fetchAllData = async () => {
    try {
      setLoading(true);
      setError('');

      // Fetch semua surat masuk menggunakan axios
      const suratResponse = await api.get('/surat-masuk/all');

      // Fetch statistik menggunakan axios
      const statsResponse = await api.get('/surat-masuk/stats');

      setSuratData(suratResponse.data?.data || []);
      setStats(statsResponse.data?.stats || {});

    } catch (err) {
      console.error('Error fetching data:', err);

      if (err.response) {
        // Server responded with error status
        const errorMessage = err.response.data?.error || err.response.data?.message || `Server error: ${err.response.status}`;
        setError(errorMessage);
        toast.error(errorMessage);
      } else if (err.request) {
        // Request was made but no response received
        setError('Tidak ada respon dari server. Pastikan server backend berjalan.');
        toast.error('Tidak ada respon dari server');
      } else {
        // Something else happened
        setError('Terjadi kesalahan saat mengambil data');
        toast.error('Terjadi kesalahan saat mengambil data');
      }
    } finally {
      setLoading(false);
    }
  };

  const formatDate = (dateString) => {
    if (!dateString) return '-';
    return new Date(dateString).toLocaleDateString('id-ID', {
      day: '2-digit',
      month: 'short',
      year: 'numeric'
    });
  };

  const getStatusBadge = (status) => {
    const styles = {
      pending: 'bg-yellow-100 text-yellow-800',
      processed: 'bg-green-100 text-green-800'
    };

    return (
      <span className={`px-2 py-1 rounded-full text-xs font-medium ${styles[status] || 'bg-gray-100 text-gray-800'}`}>
        {status === 'pending' ? 'Pending' : status === 'processed' ? 'Diproses' : status}
      </span>
    );
  };

  // Data untuk chart jabatan
  const jabatanChartData = Object.entries(stats?.byJabatan || {}).map(([jabatan, count]) => ({
    jabatan: jabatan.replace(/-/g, ' ').replace(/\b\w/g, l => l.toUpperCase()),
    jumlah: count
  }));

  // Data untuk pie chart status
  const statusChartData = [
    { name: 'Pending', value: stats?.pending || 0, color: '#fbbf24' },
    { name: 'Diproses', value: stats?.processed || 0, color: '#10b981' }
  ];

  const handleDownloadPDF = async (suratId, nomorSurat) => {
    setIsDownloading(true);
    setDownloadProgress(0);

    try {
      const response = await api.get(`/surat/${suratId}/pdf`, {
        responseType: 'blob',
        onDownloadProgress: (progressEvent) => {
          const total = progressEvent.total;
          const current = progressEvent.loaded;
          if (total) {
            const percentage = Math.round((current / total) * 100);
            setDownloadProgress(percentage);
          }
        }
      });

      // Create blob URL and download
      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', `disposisi-${nomorSurat || suratId}.pdf`);
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.URL.revokeObjectURL(url);

      toast.success('PDF berhasil diunduh!');

    } catch (err) {
      console.error('Error downloading PDF:', err);

      if (err.response) {
        const errorMessage = err.response.data?.error || 'Gagal mengunduh PDF';
        toast.error(errorMessage);
      } else if (err.request) {
        toast.error('Tidak ada respon dari server saat mengunduh PDF');
      } else {
        toast.error('Terjadi kesalahan saat mengunduh PDF');
      }
    } finally {
      setIsDownloading(false);
      setDownloadProgress(0);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="">
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded">
          <strong>Error:</strong> {error}
          <button
            onClick={fetchAllData}
            className="ml-4 bg-red-500 text-white px-3 py-1 rounded text-sm hover:bg-red-600"
          >
            Retry
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="">
      <div className="">
        {/* Header */}
        <div className="mb-8">
          <div className='flex gap-x-2 items-center mb-2'>
            <div className="inline-flex items-center justify-center w-10 h-10 bg-gradient-to-bl from-blue-500 to-blue-300 rounded-lg shadow-lg">
              <Database className="w-6 h-6 text-white" />
            </div>
            <h1 className="text-2xl font-bold uppercase text-blue-500">Semua Data</h1>
          </div>
          <p className="text-gray-600">Menu ini menampilkan semua data surat dari semua jabatan</p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="bg-white p-6 rounded-lg shadow-sm">
            <div className="flex items-center">
              <div className="p-2 bg-blue-100 rounded-lg">
                <FileText className="h-6 w-6 text-blue-600" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Total Surat</p>
                <p className="text-2xl font-bold text-gray-900">{stats?.total || 0}</p>
              </div>
            </div>
          </div>

          <div className="bg-white p-6 rounded-lg shadow-sm ">
            <div className="flex items-center">
              <div className="p-2 bg-yellow-100 rounded-lg">
                <Clock className="h-6 w-6 text-yellow-600" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Pending</p>
                <p className="text-2xl font-bold text-gray-900">{stats?.pending || 0}</p>
              </div>
            </div>
          </div>

          <div className="bg-white p-6 rounded-lg shadow-sm ">
            <div className="flex items-center">
              <div className="p-2 bg-green-100 rounded-lg">
                <CheckCircle className="h-6 w-6 text-green-600" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Diproses</p>
                <p className="text-2xl font-bold text-gray-900">{stats?.processed || 0}</p>
              </div>
            </div>
          </div>
        </div>

        {/* Charts */}
        <div className="grid grid-cols-1 gap-8 mb-8">
          {/* Bar Chart - Surat per Jabatan */}
          <div className="group relative bg-gradient-to-br from-white to-slate-50/50 p-8 rounded-2xl shadow-lg shadow-slate-200/50 border border-slate-200/60 hover:shadow-xl hover:shadow-slate-200/60 transition-all duration-300">
            <div className="absolute inset-0 bg-gradient-to-br from-blue-500/5 to-indigo-500/5 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
            <div className="relative">
              <div className="flex items-center space-x-3 mb-6">
                <div className="w-2 h-8 bg-gradient-to-b from-blue-500 to-indigo-600 rounded-full"></div>
                <h3 className="text-xl font-bold text-slate-800 tracking-tight">Surat per Jabatan</h3>
              </div>
              <div className="bg-white/70 backdrop-blur-sm rounded-xl p-4 shadow-inner">
                <ResponsiveContainer width="100%" height={320}>
                  <BarChart data={jabatanChartData} margin={{ top: 20, right: 20, left: 20, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="2 4" stroke="#e2e8f0" opacity={0.6} />
                    <XAxis
                      dataKey="jabatan"
                      tick={{ fontSize: 11, fill: '#64748b' }}
                      axisLine={false}
                      tickLine={false}
                    />
                    <YAxis
                      tick={{ fontSize: 11, fill: '#64748b' }}
                      axisLine={false}
                      tickLine={false}
                    />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: 'rgba(255, 255, 255, 0.95)',
                        border: 'none',
                        borderRadius: '12px',
                        boxShadow: '0 10px 40px rgba(0, 0, 0, 0.1)',
                        backdropFilter: 'blur(10px)'
                      }}
                    />
                    <Bar
                      dataKey="jumlah"
                      fill="url(#barGradient)"
                      radius={[8, 8, 0, 0]}
                      className="hover:opacity-80 transition-opacity duration-200"
                    />
                    <defs>
                      <linearGradient id="barGradient" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="#3b82f6" />
                        <stop offset="100%" stopColor="#6366f1" />
                      </linearGradient>
                    </defs>
                  </BarChart>
                </ResponsiveContainer>
              </div>
              <div className="grid grid-cols-1 gap-3 mt-6">
                {jabatanChartData.map((entry, index) => (
                  <div key={index} className="flex items-center justify-between p-3 bg-white/60 backdrop-blur-sm rounded-xl border border-slate-200/50 hover:bg-white/80 transition-colors duration-200">
                    <div className="flex items-center space-x-3">
                      <div className="w-4 h-4 rounded-full bg-gradient-to-r from-blue-500 to-indigo-600 shadow-sm flex-shrink-0"></div>
                      <span className="text-sm font-medium text-slate-700 truncate">{entry.jabatan}</span>
                    </div>
                    <div className="text-right">
                      <span className="text-sm font-bold text-slate-800">{entry.jumlah}</span>
                      <span className="text-xs text-slate-500 ml-1">surat</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Pie Chart - Status Distribution */}
          <div className="group relative bg-gradient-to-br from-white to-slate-50/50 p-8 rounded-2xl shadow-lg shadow-slate-200/50 border border-slate-200/60 hover:shadow-xl hover:shadow-slate-200/60 transition-all duration-300">
            <div className="absolute inset-0 bg-gradient-to-br from-emerald-500/5 to-teal-500/5 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
            <div className="relative">
              <div className="flex items-center space-x-3 mb-6">
                <div className="w-2 h-8 bg-gradient-to-b from-emerald-500 to-teal-600 rounded-full"></div>
                <h3 className="text-xl font-bold text-slate-800 tracking-tight">Distribusi Status</h3>
              </div>
              <div className="bg-white/70 backdrop-blur-sm rounded-xl p-4 shadow-inner">
                <ResponsiveContainer width="100%" height={320}>
                  <PieChart>
                    <Pie
                      data={statusChartData}
                      cx="50%"
                      cy="50%"
                      innerRadius={70}
                      outerRadius={120}
                      paddingAngle={3}
                      dataKey="value"
                      className="drop-shadow-md"
                    >
                      {statusChartData.map((entry, index) => (
                        <Cell
                          key={`cell-${index}`}
                          fill={entry.color}
                          className="hover:opacity-80 transition-opacity duration-200"
                        />
                      ))}
                    </Pie>
                    <Tooltip
                      contentStyle={{
                        backgroundColor: 'rgba(255, 255, 255, 0.95)',
                        border: 'none',
                        borderRadius: '12px',
                        boxShadow: '0 10px 40px rgba(0, 0, 0, 0.1)',
                        backdropFilter: 'blur(10px)'
                      }}
                    />
                  </PieChart>
                </ResponsiveContainer>
              </div>
              <div className="grid grid-cols-2 gap-3 mt-6">
                {statusChartData.map((entry, index) => (
                  <div key={index} className="flex items-center p-3 bg-white/60 backdrop-blur-sm rounded-xl border border-slate-200/50 hover:bg-white/80 transition-colors duration-200">
                    <div className="flex items-center space-x-3 w-full">
                      <div
                        className="w-4 h-4 rounded-full shadow-sm flex-shrink-0"
                        style={{ backgroundColor: entry.color }}
                      ></div>
                      <div className="min-w-0 flex-1">
                        <span className="text-sm font-medium text-slate-700 block truncate">{entry.name}</span>
                        <span className="text-xs text-slate-500">{entry.value} items</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Tabel Surat Masuk */}
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-100">
            <thead className="bg-gray-50/50">
              <tr>
                <th className="px-8 py-4 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                  Asal Instansi
                </th>
                <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                  Tujuan
                </th>
                <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                  Perihal
                </th>
                <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                  Status
                </th>
                <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                  Tanggal
                </th>
                <th className="px-6 py-4 text-right text-xs font-semibold text-gray-600 uppercase tracking-wider">
                  Aksi
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-50">
              {suratData.map((surat, index) => (
                <tr key={surat.id} className="hover:bg-blue-50/30 transition-colors group">
                  <td className="px-8 py-6">
                    <div className="flex items-center">
                      <div className="flex-shrink-0 h-10 w-10 border border-blue-400 rounded-lg flex items-center justify-center">
                        <Building2 className="h-5 w-5 text-blue-700" />
                      </div>
                      <div className="ml-4">

                        <div className="flex items-center text-sm font-semibold text-gray-900">
                          {surat.asal_instansi}
                        </div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-6">
                    <div className="flex items-center">
                      <span className="text-sm text-gray-900 capitalize font-medium">
                        {surat.tujuan_jabatan?.replace(/-/g, ' ')}
                      </span>
                    </div>
                  </td>
                  <td className="px-6 py-6">
                    <div className="text-sm text-gray-900 max-w-xs">
                      <p className="line-clamp-2">{surat.perihal || surat.keterangan || '-'}</p>
                    </div>
                  </td>
                  <td className="px-6 py-6">
                    {getStatusBadge(surat.status)}
                  </td>
                  <td className="px-6 py-6">
                    <div className="flex items-center text-sm text-gray-500">
                      {formatDate(surat.created_at)}
                    </div>
                  </td>
                  <td className="px-6 py-6">
                    <div className="flex items-center justify-end gap-2">
                      <button
                        onClick={() => setSelectedSurat(surat)}
                        className="inline-flex items-center px-3 py-2 text-xs font-medium text-blue-700 bg-blue-50 rounded-lg hover:bg-blue-100 transition-colors group-hover:shadow-sm"
                      >
                        <Eye className="h-3 w-3 mr-1.5" />
                        Detail
                      </button>
                      {surat.status === 'processed' && (
                        <button
                          onClick={() => handleDownloadPDF(surat.id, surat.nomor_surat)}
                          disabled={isDownloading}
                          className="inline-flex items-center px-3 py-2 text-xs font-medium text-emerald-700 bg-emerald-50 rounded-lg hover:bg-emerald-100 transition-colors disabled:opacity-50 group-hover:shadow-sm"
                        >
                          <Download className="h-3 w-3 mr-1.5" />
                          {isDownloading ? `${downloadProgress}%` : 'PDF'}
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>

          {suratData.length === 0 && (
            <div className="text-center py-16">
              <div className="mx-auto h-24 w-24 bg-gray-100 rounded-full flex items-center justify-center mb-6">
                <FileText className="h-12 w-12 text-gray-400" />
              </div>
              <h3 className="text-lg font-medium text-gray-900 mb-2">Belum ada surat masuk</h3>
              <p className="text-gray-500 max-w-sm mx-auto">
                Surat masuk yang baru akan tampil di sini. Pastikan sistem sudah terhubung dengan baik.
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Modal Detail Surat */}
      {
        selectedSurat && (
          <div className="fixed inset-0 bg-gradient-to-br from-black/60 via-black/50 to-black/40 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <div className="relative w-full max-w-2xl h-[90vh] overflow-y-auto">
              {/* Background with glass morphism effect */}
              <div className="absolute inset-0 bg-white/95 backdrop-blur-xl rounded-2xl shadow-2xl border border-white/20"></div>

              {/* Content */}
              <div className="relative h-full overflow-y-auto rounded-2xl">
                {/* Header */}
                <div className="sticky top-0 bg-white backdrop-blur-sm border-b border-gray-100 px-8 py-6">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="p-2 bg-blue-500 rounded-xl">
                        <FileText className="h-6 w-6 text-white" />
                      </div>
                      <div>
                        <h3 className="text-xl font-bold text-gray-900">Detail Surat Masuk</h3>
                        <p className="text-sm text-gray-600">Informasi lengkap dokumen</p>
                      </div>
                    </div>
                    <button
                      onClick={() => setSelectedSurat(null)}
                      className="p-2 hover:bg-gray-100 rounded-xl transition-colors duration-200 group"
                    >
                      <X className="h-5 w-5 text-gray-500 group-hover:text-gray-700" />
                    </button>
                  </div>
                </div>

                {/* Content Body */}
                <div className="px-8 py-6">
                  {/* Status Badge */}
                  <div className="mb-8">
                    {getStatusBadge(selectedSurat.status)}
                  </div>

                  {/* Main Info Grid */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                    <div className="space-y-6">
                      <div className="group">
                        <label className="flex items-center gap-2 text-sm font-semibold text-gray-700 mb-2">
                          <FileText className="h-4 w-4 text-blue-500" />
                          Nomor Surat
                        </label>
                        <div className="p-4 bg-gray-50 rounded-xl border-l-4 border-blue-500">
                          <p className={`${selectedSurat.nomor_surat ? 'text-gray-900' : 'text-gray-400 italic'}`}>
                            {selectedSurat.nomor_surat || 'akan muncul bila sudah diproses jabatan terkait'}
                          </p>
                        </div>
                      </div>

                      <div className="group">
                        <label className="flex items-center gap-2 text-sm font-semibold text-gray-700 mb-2">
                          <Building2 className="h-4 w-4 text-green-500" />
                          Asal Instansi
                        </label>
                        <div className="p-4 bg-gray-50 rounded-xl border-l-4 border-green-500">
                          <p className="text-gray-900">{selectedSurat.asal_instansi}</p>
                        </div>
                      </div>

                      <div className="group">
                        <label className="flex items-center gap-2 text-sm font-semibold text-gray-700 mb-2">
                          <User className="h-4 w-4 text-purple-500" />
                          Tujuan Jabatan
                        </label>
                        <div className="p-4 bg-gray-50 rounded-xl border-l-4 border-purple-500">
                          <p className="text-gray-900 capitalize">{selectedSurat.tujuan_jabatan?.replace(/-/g, ' ')}</p>
                        </div>
                      </div>
                    </div>

                    <div className="space-y-6">
                      <div className="group">
                        <label className="flex items-center gap-2 text-sm font-semibold text-gray-700 mb-2">
                          <MessageSquare className="h-4 w-4 text-orange-500" />
                          Perihal
                        </label>
                        <div className="p-4 bg-gray-50 rounded-xl border-l-4 border-orange-500">
                          <p className={`${selectedSurat.perihal ? 'text-gray-900' : 'text-gray-500 italic'}`}>
                            {selectedSurat.perihal || 'akan muncul bila sudah diproses jabatan terkait'}
                          </p>
                        </div>
                      </div>

                      <div className="group">
                        <label className="flex items-center gap-2 text-sm font-semibold text-gray-700 mb-2">
                          <User className="h-4 w-4 text-indigo-500" />
                          Dibuat oleh
                        </label>
                        <div className="p-4 bg-gray-50 rounded-xl border-l-4 border-indigo-500">
                          <p className="text-gray-900 font-medium">{selectedSurat.users?.name}</p>
                          <p className="text-sm text-gray-600">({selectedSurat.users?.jabatan})</p>
                        </div>
                      </div>

                      <div className="group">
                        <label className="flex items-center gap-2 text-sm font-semibold text-gray-700 mb-2">
                          <Calendar className="h-4 w-4 text-teal-500" />
                          Tanggal Dibuat
                        </label>
                        <div className="p-4 bg-gray-50 rounded-xl border-l-4 border-teal-500">
                          <p className="text-gray-900">{formatDate(selectedSurat.created_at)}</p>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Description */}
                  <div className="mb-8">
                    <label className="flex items-center gap-2 text-sm font-semibold text-gray-700 mb-3">
                      <FileText className="h-4 w-4 text-gray-500" />
                      Keterangan
                    </label>
                    <div className="p-6 bg-gradient-to-br from-gray-50 to-gray-100 rounded-xl border">
                      <p className="text-gray-900 leading-relaxed">{selectedSurat.keterangan}</p>
                    </div>
                  </div>

                  {/* Processing Information */}
                  {selectedSurat.processed_at && (
                    <div className="mb-8 p-6 bg-gradient-to-r from-emerald-50 to-blue-50 rounded-xl border border-emerald-200">
                      <h4 className="font-semibold text-gray-900 mb-4 flex items-center gap-2">
                        <CheckCircle className="h-5 w-5 text-emerald-600" />
                        Informasi Pemrosesan
                      </h4>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <label className="text-xs font-medium text-gray-600 uppercase tracking-wide">Diproses oleh</label>
                          <p className="text-gray-900 font-medium">{selectedSurat.processed_user?.name}</p>
                        </div>
                        <div>
                          <label className="text-xs font-medium text-gray-600 uppercase tracking-wide">Waktu Pemrosesan</label>
                          <p className="text-gray-900">{formatDate(selectedSurat.processed_at)}</p>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Additional Information */}
                  {(selectedSurat.disposisi_kepada || selectedSurat.catatan) && (
                    <div className="mb-8 space-y-4">
                      {selectedSurat.disposisi_kepada && (
                        <div className="p-4 bg-blue-50 rounded-xl border border-blue-200">
                          <label className="text-xs font-medium text-blue-700 uppercase tracking-wide mb-1 block">
                            Disposisi Kepada
                          </label>
                          <p className="text-blue-900 font-medium">{selectedSurat.disposisi_kepada}</p>
                        </div>
                      )}

                      {selectedSurat.catatan && (
                        <div className="p-4 bg-amber-50 rounded-xl border border-amber-200">
                          <label className="text-xs font-medium text-amber-700 uppercase tracking-wide mb-1 block">
                            Catatan
                          </label>
                          <p className="text-amber-900">{selectedSurat.catatan}</p>
                        </div>
                      )}
                    </div>
                  )}
                </div>

                {/* Footer Actions */}
                <div className="sticky bottom-0 bg-white/90 backdrop-blur-sm border-t border-gray-100 px-8 py-6">
                  <div className="flex justify-end gap-3">
                    {selectedSurat.status === 'processed' && (
                      <button
                        onClick={() => handleDownloadPDF(selectedSurat.id, selectedSurat.nomor_surat)}
                        disabled={isDownloading}
                        className="inline-flex items-center gap-2 bg-gradient-to-r from-blue-500 to-blue-300 hover:from-blue-500 hover:to-blue-700 cursor-pointer text-white px-6 py-3 rounded-xl font-medium transition-all duration-200 shadow-lg hover:shadow-xl disabled:opacity-50 disabled:cursor-not-allowed transform"
                      >
                        <Download className="h-4 w-4" />
                        {isDownloading ? `Mengunduh... ${downloadProgress}%` : 'Download PDF'}
                      </button>
                    )}
                    <button
                      onClick={() => setSelectedSurat(null)}
                      className="inline-flex items-center gap-2 bg-gray-100 hover:bg-gray-200 text-gray-700 hover:text-gray-900 px-6 py-3 rounded-xl font-medium transition-all duration-200"
                    >
                      Tutup
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )
      }
    </div >
  );
};

export default SemuaData;