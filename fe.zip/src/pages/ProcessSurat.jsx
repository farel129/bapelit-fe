import { useParams, useNavigate } from 'react-router-dom'
import { Download, Eye, FileText, Save, X, Plus, Trash2 } from 'lucide-react'
import { useEffect, useState } from 'react'
import toast from 'react-hot-toast'

// Custom hooks
import { useSuratDetail } from '../hooks/useSuratDetail'
import { useSuratMasuk } from '../hooks/useSuratMasuk'

// Components
import ProcessingPopup from '../components/ProcessingPopup'
import SuratInfo from '../components/SuratInfo'
import PhotoGalleryModal from '../components/PhotoGalleryModal'
import { api } from '../utils/api'

const ForwardModal = ({ open, onClose, onSubmit, userOptions, loading }) => {
  const [selectedUsers, setSelectedUsers] = useState([]);
  const [catatan, setCatatan] = useState('');
  const [searchTerm, setSearchTerm] = useState('');

  // Filter users berdasarkan search term
  const filteredUsers = userOptions.filter(user => 
    user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    user.jabatan.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Group users by jabatan for better organization
  const groupedUsers = filteredUsers.reduce((acc, user) => {
    if (!acc[user.jabatan]) {
      acc[user.jabatan] = [];
    }
    acc[user.jabatan].push(user);
    return acc;
  }, {});

  const handleUserToggle = (user) => {
    const isSelected = selectedUsers.find(u => u.id === user.id);
    if (isSelected) {
      setSelectedUsers(selectedUsers.filter(u => u.id !== user.id));
    } else {
      setSelectedUsers([...selectedUsers, { nama: user.name, jabatan: user.jabatan }]);
    }
  };

  const handleSubmit = () => {
    if (selectedUsers.length === 0) {
      toast.error('Pilih minimal satu user untuk diteruskan');
      return;
    }
    onSubmit(selectedUsers, catatan);
  };

  const resetForm = () => {
    setSelectedUsers([]);
    setCatatan('');
    setSearchTerm('');
  };

  useEffect(() => {
    if (!open) {
      resetForm();
    }
  }, [open]);

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/30 backdrop-blur-sm">
      <div className="bg-white rounded-xl p-6 w-full max-w-2xl max-h-[80vh] shadow-2xl overflow-hidden flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between mb-4 pb-4 border-b">
          <h2 className="font-bold text-blue-600 text-lg">Teruskan ke Bawahan Spesifik</h2>
          <button 
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-full transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
        
        {loading ? (
          <div className="flex-1 flex items-center justify-center">
            <div className="text-center">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-2"></div>
              <p className="text-gray-500">Memuat daftar bawahan...</p>
            </div>
          </div>
        ) : userOptions.length === 0 ? (
          <div className="flex-1 flex items-center justify-center">
            <div className="text-center text-gray-500">
              <FileText className="w-12 h-12 mx-auto mb-2 opacity-50" />
              <p>Tidak ada bawahan dalam bidang yang sama</p>
            </div>
          </div>
        ) : (
          <div className="flex-1 flex flex-col overflow-hidden">
            {/* Search Input */}
            <div className="mb-4">
              <input
                type="text"
                placeholder="Cari berdasarkan nama atau jabatan..."
                className="w-full border rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                value={searchTerm}
                onChange={e => setSearchTerm(e.target.value)}
              />
            </div>

            {/* Selected Users Display */}
            {selectedUsers.length > 0 && (
              <div className="mb-4 p-3 bg-blue-50 rounded-lg">
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-sm font-semibold text-blue-700">
                    Dipilih ({selectedUsers.length}):
                  </span>
                </div>
                <div className="flex flex-wrap gap-2">
                  {selectedUsers.map((user, index) => (
                    <span 
                      key={index}
                      className="inline-flex items-center gap-1 px-2 py-1 bg-blue-100 text-blue-800 rounded-full text-xs"
                    >
                      {user.nama} ({user.jabatan})
                      <button
                        onClick={() => {
                          setSelectedUsers(selectedUsers.filter((_, i) => i !== index));
                        }}
                        className="hover:bg-blue-200 rounded-full p-0.5"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </span>
                  ))}
                </div>
              </div>
            )}

            {/* User List */}
            <div className="flex-1 overflow-y-auto border rounded-lg">
              {Object.keys(groupedUsers).length === 0 ? (
                <div className="p-4 text-center text-gray-500">
                  Tidak ada user yang sesuai dengan pencarian
                </div>
              ) : (
                Object.entries(groupedUsers).map(([jabatan, users]) => (
                  <div key={jabatan} className="border-b last:border-b-0">
                    <div className="bg-gray-50 px-4 py-2 font-semibold text-gray-700 text-sm">
                      {jabatan} ({users.length})
                    </div>
                    {users.map(user => {
                      const isSelected = selectedUsers.find(u => u.nama === user.name && u.jabatan === user.jabatan);
                      return (
                        <label
                          key={user.id}
                          className="flex items-center px-4 py-3 hover:bg-gray-50 cursor-pointer border-b last:border-b-0"
                        >
                          <input
                            type="checkbox"
                            checked={!!isSelected}
                            onChange={() => handleUserToggle(user)}
                            className="mr-3 w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded focus:ring-blue-500"
                          />
                          <div className="flex-1">
                            <div className="font-medium text-gray-900">{user.name}</div>
                            <div className="text-sm text-gray-500">{user.email}</div>
                          </div>
                        </label>
                      );
                    })}
                  </div>
                ))
              )}
            </div>

            {/* Catatan */}
            <div className="mt-4">
              <label className="block mb-2 text-sm font-semibold text-gray-700">
                Catatan (opsional)
              </label>
              <textarea
                className="w-full border rounded-lg p-3 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 resize-none"
                rows={3}
                value={catatan}
                onChange={e => setCatatan(e.target.value)}
                placeholder="Tambahkan catatan untuk bawahan yang dipilih..."
              />
            </div>
          </div>
        )}
        
        {/* Footer */}
        <div className="flex justify-end gap-3 mt-6 pt-4 border-t">
          <button 
            onClick={onClose} 
            className="px-6 py-2 rounded-lg bg-gray-100 hover:bg-gray-200 font-medium transition-colors"
          >
            Batal
          </button>
          <button
            onClick={handleSubmit}
            className="px-6 py-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-medium disabled:bg-gray-400 disabled:cursor-not-allowed transition-colors"
            disabled={selectedUsers.length === 0 || loading}
          >
            Teruskan ({selectedUsers.length})
          </button>
        </div>
      </div>
    </div>
  );
};

const ProcessSurat = () => {
  const { id } = useParams()
  const navigate = useNavigate()
  const [showForward, setShowForward] = useState(false);
  const [forwardLoading, setForwardLoading] = useState(false);
  const [acceptLoading, setAcceptLoading] = useState(false);
  const [bawahanOptions, setBawahanOptions] = useState([]);
  const [loadingBawahan, setLoadingBawahan] = useState(false);
  const [userInfo, setUserInfo] = useState(null);
  
  // State untuk melacak apakah surat sudah diproses atau diteruskan
  const [isActionTaken, setIsActionTaken] = useState(false);

  // Form data state - integrated from useSuratForm
  const [formData, setFormData] = useState({
    nomor_surat: '',
    perihal: '',
    disposisi_kepada: '',
    tindakan: [],
    sifat: '',
    catatan: ''
  })

  // Processing states - integrated from useSuratProcessing
  const [processing, setProcessing] = useState(false)
  const [showProcessingPopup, setShowProcessingPopup] = useState(false)
  const [processingComplete, setProcessingComplete] = useState(false)
  const [downloadProgress, setDownloadProgress] = useState(0)
  const [isDownloading, setIsDownloading] = useState(false)

  // Only remaining hook
  const { surat, loading, updateSuratStatus } = useSuratDetail(id)
  const { selectedPhotos, setSelectedPhotos } = useSuratMasuk()

  

  // Processing handlers - integrated from useSuratProcessing
  const handleSubmit = async (formData) => {
    setProcessing(true)
    setShowProcessingPopup(true)
    setProcessingComplete(false)

    try {
      // Convert array back to string for backend compatibility if needed
      const dataToSend = {
        ...formData,
        tindakan: formData.tindakan.join(', ') // Join multiple actions with comma
      }
      
      await api.post(`/surat/${id}/process`, dataToSend)
      
      // Simulate processing delay for better UX
      await new Promise(resolve => setTimeout(resolve, 1500))
      
      setProcessingComplete(true)
      toast.success('Surat berhasil diproses!')
      
      // Update parent component status
      updateSuratStatus('processed')
      
      // Set action taken to true to disable the button
      setIsActionTaken(true)
      
    } catch (error) {
      console.error("Full error object:", error)
      setShowProcessingPopup(false)
      
      if (error.response) {
        console.error("Response data:", error.response.data)
        console.error("Response status:", error.response.status)
        toast.error(error.response.data?.error || 'Gagal memproses surat')
      } else if (error.request) {
        console.error("No response from server:", error.request)
        toast.error('Tidak ada respon dari server.')
      } else {
        console.error("Error saat setup request:", error.message)
        toast.error('Terjadi kesalahan saat mengirim data.')
      }
    } finally {
      setProcessing(false)
    }
  }

  const handleDownloadPDF = async () => {
    setIsDownloading(true)
    setDownloadProgress(0)

    try {
      const response = await api.get(`/surat/${id}/pdf`, {
        responseType: 'blob',
        onDownloadProgress: (progressEvent) => {
          const total = progressEvent.total
          const current = progressEvent.loaded
          const percentage = Math.round((current / total) * 100)
          setDownloadProgress(percentage)
        }
      })

      const url = window.URL.createObjectURL(new Blob([response.data]))
      const link = document.createElement('a')
      link.href = url
      link.setAttribute('download', `surat-${id}.pdf`)
      document.body.appendChild(link)
      link.click()
      link.remove()
      window.URL.revokeObjectURL(url)
      
      toast.success('PDF berhasil diunduh!')
      setShowProcessingPopup(false)
      
    } catch (error) {
      toast.error('Gagal mengunduh PDF')
    } finally {
      setIsDownloading(false)
      setDownloadProgress(0)
    }
  }

  const closePopup = () => {
    setShowProcessingPopup(false)
    setProcessingComplete(false)
    setDownloadProgress(0)
  }

  // Effect for form data initialization - integrated from useSuratForm
  useEffect(() => {
    if (surat) {
      // Handle tindakan conversion from string to array
      let tindakanArray = []
      if (surat.tindakan) {
        if (Array.isArray(surat.tindakan)) {
          tindakanArray = surat.tindakan
        } else if (typeof surat.tindakan === 'string') {
          // Split by comma and trim whitespace
          tindakanArray = surat.tindakan
            .split(',')
            .map(item => item.trim())
            .filter(item => item.length > 0)
        }
      }

      console.log("Tindakan yang akan diset:", tindakanArray)

      setFormData({
        nomor_surat: surat.nomor_surat || '',
        perihal: surat.perihal || '',
        disposisi_kepada: surat.disposisi_kepada || '',
        tindakan: tindakanArray,
        sifat: surat.sifat || '',
        catatan: surat.catatan || ''
      })
      
      // Cek apakah surat sudah diproses sebelumnya
      if (surat.status === 'processed' || surat.status === 'forwarded') {
        setIsActionTaken(true)
      }
    }
  }, [surat])

  // Updated effect to fetch user options instead of jabatan options
  useEffect(() => {
    const fetchBawahanOptions = async () => {
      setLoadingBawahan(true);
      try {
        const response = await api.get('/users/bawahan-bidang-detail');
        console.log('Bawahan response:', response.data);
        
        // Set user options dengan structure yang lengkap
        setBawahanOptions(response.data.data || []);
        setUserInfo({ 
          bidang: response.data.bidang,
          total: response.data.total 
        });
      } catch (error) {
        console.error('Gagal mengambil data bawahan:', error);
        setBawahanOptions([]);
        toast.error('Gagal memuat data bawahan');
      } finally {
        setLoadingBawahan(false);
      }
    };

    fetchBawahanOptions();
  }, []);

  const onFormSubmit = (e) => {
    e.preventDefault()
    // Cek apakah action sudah diambil sebelumnya
    if (!isActionTaken) {
      handleSubmit(formData)
    }
  }

  const handleCancel = () => {
    navigate('/')
  }

  // Updated handleForward to use new API format
  const handleForward = async (selectedUsers, catatan) => {
    setForwardLoading(true);
    try {
      console.log('Sending forward request:', {
        bawahan_users: selectedUsers,
        catatan
      });

      const response = await api.post(`/surat/${id}/forward`, {
        bawahan_users: selectedUsers,
        catatan,
      });
      
      setShowForward(false);
      
      // Set action taken to true to disable the process button
      setIsActionTaken(true);
      
      const forwardedCount = response.data.forwarded_to?.length || selectedUsers.length;
      const bidangInfo = response.data.bidang ? ` (Bidang: ${response.data.bidang})` : '';
      
      toast.success(`Surat berhasil diteruskan ke ${forwardedCount} user${bidangInfo}!`);
      
      // Optional: Show detail of forwarded users
      const forwardedNames = response.data.forwarded_to?.map(u => u.name).join(', ') || 
                            selectedUsers.map(u => u.nama).join(', ');
      console.log('Diteruskan kepada:', forwardedNames);
      
    } catch (err) {
      const errorMessage = err.response?.data?.error || 'Gagal meneruskan surat!';
      toast.error(errorMessage);
      console.error('Forward error:', err.response?.data || err);
    } finally {
      setForwardLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    )
  }

  if (!surat) {
    return (
      <div className="text-center py-12">
        <p className="text-gray-500">Surat tidak ditemukan</p>
      </div>
    )
  }

  return (
    <div className="max-w-4xl mx-auto">
      {/* Processing Popup */}
      <ProcessingPopup
        showProcessingPopup={showProcessingPopup}
        processingComplete={processingComplete}
        isDownloading={isDownloading}
        downloadProgress={downloadProgress}
        onDownloadPDF={handleDownloadPDF}
        onClose={closePopup}
      />

      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex gap-x-3 items-center">
          <div className="inline-flex items-center justify-center w-10 h-10 bg-gradient-to-bl from-blue-500 to-blue-300 rounded-lg shadow-lg">
            <Eye className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-blue-500 uppercase">Verifikasi Surat</h1>
            {userInfo?.bidang && (
              <p className="text-sm text-gray-600">
                Bidang: {userInfo.bidang} 
                {userInfo.total > 0 && ` • ${userInfo.total} bawahan tersedia`}
              </p>
            )}
          </div>
        </div>
        
        <div className="flex gap-2">
          {surat.status === 'processed' && (
            <button
              onClick={handleDownloadPDF}
              className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-gradient-to-bl from-blue-500 to-blue-300 hover:bg-gradient-to-bl hover:from-blue-500 hover:to-blue-500 cursor-pointer"
            >
              <Download className="w-4 h-4 mr-2" />
              Download PDF
            </button>
          )}
          
          <button
            onClick={() => setShowForward(true)}
            className={`inline-flex items-center px-4 py-2 border text-sm font-medium rounded-md ${
              isActionTaken 
                ? 'border-gray-300 text-gray-400 bg-gray-100 cursor-not-allowed' 
                : 'border-blue-500 text-blue-600 bg-white hover:bg-blue-50 cursor-pointer'
            }`}
            disabled={loadingBawahan || isActionTaken || bawahanOptions.length === 0}
          >
            {loadingBawahan ? 'Memuat...' : `Teruskan ke Bawahan${bawahanOptions.length > 0 ? ` (${bawahanOptions.length})` : ''}`}
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Surat Information */}
        <SuratInfo surat={surat} onOpenPhotos={setSelectedPhotos} />

        {/* Process Form - Fully Integrated */}
        <div className="max-w-4xl mx-auto">
          <div className="bg-white/80 backdrop-blur-sm shadow-xl rounded-2xl border border-white/20 overflow-hidden">
            {/* Header */}
            <div className="p-8">
              <div className="flex items-center space-x-3">
                <div className="">
                  <FileText className="w-8 h-8 text-blue-500" />
                </div>
                <div>
                  <h2 className="text-lg font-bold text-blue-500">Proses Surat</h2>
                  {isActionTaken && (
                    <p className="text-sm text-green-600 mt-1">✓ Surat sudah diproses atau diteruskan</p>
                  )}
                </div>
              </div>
            </div>
             
            {/* Form Content */}
            <div className="p-8">
              <form onSubmit={onFormSubmit} className="space-y-8">
                <div className="flex justify-end space-x-4 pt-6 border-t border-slate-200">
                  <button
                    type="button"
                    onClick={handleCancel}
                    className="px-8 py-3 text-slate-600 cursor-pointer font-semibold bg-slate-100 hover:bg-slate-200 rounded-xl transition-all duration-200 focus:ring-4 focus:ring-slate-300/30"
                  >
                    Batal
                  </button>
                  <button
                    type="submit"
                    disabled={processing || isActionTaken}
                    className={`inline-flex items-center px-8 py-3 font-semibold rounded-xl shadow-lg transition-all duration-200 focus:ring-4 ${
                      processing || isActionTaken
                        ? 'bg-gray-400 text-gray-200 cursor-not-allowed shadow-gray-300/25'
                        : 'bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white shadow-blue-500/25 hover:shadow-blue-500/40 cursor-pointer focus:ring-blue-500/30'
                    }`}
                  >
                    {processing ? (
                      <>
                        <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin mr-3"></div>
                        Memproses...
                      </>
                    ) : isActionTaken ? (
                      <>
                        <Save className="w-5 h-5 mr-3" />
                        Sudah Diproses
                      </>
                    ) : (
                      <>
                        <Save className="w-5 h-5 mr-3" />
                        Proses Surat
                      </>
                    )}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>

      {/* Updated Modal Forward */}
      <ForwardModal
        open={showForward}
        onClose={() => setShowForward(false)}
        onSubmit={handleForward}
        userOptions={bawahanOptions}
        loading={loadingBawahan || forwardLoading}
      />

      {/* Photo Gallery Modal */}
      {selectedPhotos && (
        <PhotoGalleryModal
          photos={selectedPhotos.photos}
          suratInfo={selectedPhotos.info}
          onClose={() => setSelectedPhotos(null)}
        />
      )}
    </div>
  )
}

export default ProcessSurat