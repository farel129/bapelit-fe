import React, { useState, useEffect } from 'react';
import { Users, Mail, Calendar, UserCheck, Search, Filter, RefreshCw, Clock, Award, TrendingUp, Sparkles } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import toast from 'react-hot-toast';
import { api } from '../utils/api';

const UsersList = () => {
  const { user } = useAuth();
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterJabatan, setFilterJabatan] = useState('');
  const [refreshing, setRefreshing] = useState(false);

  // Fetch users data
  const fetchUsers = async (showLoadingToast = false) => {
    try {
      if (showLoadingToast) {
        setRefreshing(true);
        toast.loading('Memuat data user...');
      }

      const response = await api.get('/users/basic');
      const data = response.data;
      setUsers(data.data || []);

      if (showLoadingToast) {
        toast.dismiss();
        toast.success(`Berhasil memuat ${data.total} user`);
      }


      if (showLoadingToast) {
        toast.dismiss();
        toast.success(`Berhasil memuat ${data.total} user`);
      }
    } catch (error) {
      console.error('Error fetching users:', error);
      toast.error(error.message || 'Gagal memuat data user');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  // Filter users based on search term and jabatan
  const filteredUsers = users.filter(userData => {
    const matchesSearch = userData.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      userData.email.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesJabatan = !filterJabatan || userData.jabatan === filterJabatan;
    return matchesSearch && matchesJabatan;
  });

  // Get unique jabatan for filter dropdown
  const uniqueJabatan = [...new Set(users.map(userData => userData.jabatan))];

  // Format date
  const formatDate = (dateString) => {
    if (!dateString) return '-';
    const date = new Date(dateString);
    return date.toLocaleDateString('id-ID', {
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    });
  };

  // Handle refresh
  const handleRefresh = () => {
    fetchUsers(true);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Memuat data user...</p>
        </div>
      </div>
    );
  }

  const getGradientForUser = (index) => {
    const gradients = [
      'from-violet-500 via-purple-500 to-pink-500',
      'from-blue-500 via-cyan-500 to-teal-500',
      'from-orange-500 via-red-500 to-pink-500',
      'from-green-500 via-emerald-500 to-cyan-500',
      'from-indigo-500 via-purple-500 to-pink-500',
      'from-yellow-500 via-orange-500 to-red-500'
    ];
    return gradients[index % gradients.length];
  };

  return (
    <div className="">
      <div className=" mx-auto">
        {/* Floating Header with Glassmorphism */}
        <div className="backdrop-blur-xl bg-white/70 rounded-2xl shadow-lg border border-white/20 p-8 mb-8 relative overflow-hidden">
          <div className="relative">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center space-x-4">
                <div className="relative">
                  <div className="bg-gradient-to-r from-blue-500 to-blue-300 p-3 rounded-xl shadow-lg">
                    <Users className="w-7 h-7 text-white" />
                  </div>
                  <div className="absolute -top-1 -right-1 w-4 h-4 bg-gradient-to-r from-green-400 to-emerald-500 rounded-full animate-pulse"></div>
                </div>
                <div>
                  <h1 className="text-2xl uppercase font-bold text-blue-500">
                    Daftar User
                  </h1>
                  <p className="text-gray-600 font-medium">
                    <span className="inline-flex items-center space-x-1">
                      <Sparkles className="w-4 h-4 text-blue-500" />
                      <span>{users.length} users</span>
                    </span>
                  </p>
                </div>
              </div>
              <button
                onClick={handleRefresh}
                disabled={refreshing}
                className="group relative overflow-hidden bg-gradient-to-r from-blue-500 to-purple-600 text-white px-6 py-3 rounded-xl font-semibold shadow-lg hover:shadow-xl transform hover:-translate-y-1 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <div className="absolute inset-0 bg-gradient-to-r from-purple-600 to-pink-600 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                <div className="relative flex items-center space-x-2">
                  <RefreshCw className={`w-5 h-5 ${refreshing ? 'animate-spin' : 'group-hover:rotate-180'} transition-transform duration-500`} />
                  <span>Refresh</span>
                </div>
              </button>
            </div>

            {/* Filter */}
            <div className="">
              <div className="relative group">
                <div className="relative">
                  <Filter className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-800 w-5 h-5 transition-colors group-focus-within:text-gray-800" />
                  <select
                    value={filterJabatan}
                    onChange={(e) => setFilterJabatan(e.target.value)}
                    className="pl-12 pr-10 py-3 bg-white/70 backdrop-blur-sm border border-blue-500/30 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all duration-300 appearance-none cursor-pointer"
                  >
                    <option value="">Filter Jabatan</option>
                    {uniqueJabatan.map(jabatan => (
                      <option key={jabatan} value={jabatan}>{jabatan}</option>
                    ))}
                  </select>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Users Grid with Enhanced Cards */}
        {filteredUsers.length === 0 ? (
          <div className="backdrop-blur-xl bg-white/70 rounded-2xl shadow-xl border border-white/20 p-16 text-center">
            <div className="relative">
              <div className="w-20 h-20 bg-gradient-to-r from-gray-300 to-gray-400 rounded-full flex items-center justify-center mx-auto mb-6">
                <Users className="w-10 h-10 text-white" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">
                {searchTerm || filterJabatan ? 'No matching members' : 'No members yet'}
              </h3>
              <p className="text-gray-600 max-w-md mx-auto">
                {searchTerm || filterJabatan
                  ? 'Try adjusting your search terms or filters'
                  : 'Start building your amazing team'}
              </p>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filteredUsers.map((userData, index) => (
              <div key={userData.id} className="group relative">
                {/* Card Glow Effect */}
                <div className="absolute inset-0 bg-gradient-to-r from-blue-500/20 to-purple-500/20 rounded-2xl blur-xl opacity-0 group-hover:opacity-100 transition-all duration-500"></div>

                {/* Main Card */}
                <div className="relative backdrop-blur-xl bg-white/80 rounded-2xl shadow-lg border border-white/30 hover:shadow-2xl transform hover:-translate-y-2 transition-all duration-500 overflow-hidden">
                  {/* Background Pattern */}
                  <div className="absolute top-0 right-0 w-32 h-32 opacity-5">
                    <div className="w-full h-full bg-gradient-to-br from-blue-500 to-purple-600 rounded-full transform translate-x-16 -translate-y-16"></div>
                  </div>

                  <div className="relative p-6">
                    {/* Enhanced Avatar */}
                    <div className="relative mb-6">
                      <div className={`w-20 h-20 bg-gradient-to-r ${getGradientForUser(index)} rounded-2xl mx-auto shadow-lg transform group-hover:rotate-12 group-hover:scale-110 transition-all duration-500 flex items-center justify-center`}>
                        <span className="text-white font-bold text-2xl">
                          {userData.name?.charAt(0)?.toUpperCase() || '?'}
                        </span>
                      </div>
                      {/* Online Indicator
                      <div className="absolute -bottom-1 -right-1 w-6 h-6 bg-gradient-to-r from-green-400 to-emerald-500 rounded-full border-3 border-white shadow-lg">
                        <div className="w-full h-full rounded-full bg-green-400 animate-pulse"></div>
                      </div> */}
                    </div>

                    {/* User Info with Better Typography */}
                    <div className="text-center space-y-3">
                      <h3 className="font-bold text-gray-900 text-lg group-hover:text-transparent group-hover:bg-gradient-to-r group-hover:from-blue-600 group-hover:to-purple-600 group-hover:bg-clip-text transition-all duration-300">
                        {userData.name}
                      </h3>

                      <div className="flex items-center justify-center space-x-2 bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg py-2 px-3">
                        <span className="text-sm text-blue-700 font-semibold">{userData.jabatan}</span>
                      </div>
                    </div>

                    {/* Current User Badge */}
                    {user && userData.id === user.id && (
                      <div className="absolute top-4 right-4">
                        <div className="bg-gradient-to-r from-blue-500 to-teal-500 text-white px-3 py-1 rounded-full text-xs font-bold shadow-lg">
                          <span className="flex items-center space-x-1">
                            <Award className="w-3 h-3" />
                            <span>Anda</span>
                          </span>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Enhanced Stats Summary */}
        {users.length > 0 && (
          <div className="mt-8 backdrop-blur-xl bg-white/70 rounded-2xl shadow-xl border border-white/20 p-8 relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-r from-indigo-500/5 to-purple-500/5"></div>
            <div className="relative">
              <div className="flex items-center space-x-3 mb-6">
                <TrendingUp className="w-6 h-6 text-indigo-600" />
                <h3 className="text-xl font-bold bg-gradient-to-r from-gray-900 to-gray-600 bg-clip-text text-transparent">
                  User Analitis
                </h3>
              </div>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-6">
                <div className="text-center group">
                  <div className="bg-gradient-to-r from-blue-500 to-cyan-500 w-16 h-16 rounded-2xl mx-auto mb-3 flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                    <Users className="w-8 h-8 text-white" />
                  </div>
                  <div className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-cyan-600 bg-clip-text text-transparent">
                    {users.length}
                  </div>
                  <div className="text-sm text-gray-600 font-medium">Total Users</div>
                </div>
                <div className="text-center group">
                  <div className="bg-gradient-to-r from-emerald-500 to-green-500 w-16 h-16 rounded-2xl mx-auto mb-3 flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                    <Award className="w-8 h-8 text-white" />
                  </div>
                  <div className="text-3xl font-bold bg-gradient-to-r from-emerald-600 to-green-600 bg-clip-text text-transparent">
                    {uniqueJabatan.length}
                  </div>
                  <div className="text-sm text-gray-600 font-medium">Jabatan unik</div>
                </div>
                <div className="text-center group">
                  <div className="bg-gradient-to-r from-purple-500 to-pink-500 w-16 h-16 rounded-2xl mx-auto mb-3 flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                    <Filter className="w-8 h-8 text-white" />
                  </div>
                  <div className="text-3xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
                    {filteredUsers.length}
                  </div>
                  <div className="text-sm text-gray-600 font-medium">Berdasarkan Filter</div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default UsersList;