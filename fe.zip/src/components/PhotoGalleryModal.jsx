// components/PhotoGalleryModal.jsx
import React, { useState, useEffect } from 'react';
import { RefreshCw, AlertCircle, X, Maximize2, Minimize2, Image } from 'lucide-react';
import { suratService } from '../services/suratService';

const PhotoGalleryModal = ({ photos, suratInfo, onClose }) => {
  const [currentPhotoIndex, setCurrentPhotoIndex] = useState(0);
  const [imageError, setImageError] = useState({});
  const [imageDataUrls, setImageDataUrls] = useState({});
  const [loadingImages, setLoadingImages] = useState({});
  const [isFullscreen, setIsFullscreen] = useState(false);

  const toggleFullscreen = () => {
    setIsFullscreen(!isFullscreen);
  };

  const handleImageDoubleClick = () => {
    toggleFullscreen();
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Escape') {
      if (isFullscreen) {
        setIsFullscreen(false);
      } else {
        onClose();
      }
    } else if (e.key === 'f' || e.key === 'F') {
      toggleFullscreen();
    } else if (e.key === 'ArrowLeft') {
      goToPrevious();
    } else if (e.key === 'ArrowRight') {
      goToNext();
    }
  };

  // Auto focus for keyboard navigation
  useEffect(() => {
    const handleKeyDownGlobal = (e) => handleKeyDown(e);
    window.addEventListener('keydown', handleKeyDownGlobal);
    return () => window.removeEventListener('keydown', handleKeyDownGlobal);
  }, [isFullscreen]);

  const fetchPhoto = async (photo, index) => {
    setLoadingImages(prev => ({ ...prev, [index]: true }));
    setImageError(prev => ({ ...prev, [index]: false }));

    try {
      const dataUrl = await suratService.getPhoto(photo.url);
      setImageDataUrls(prev => ({ ...prev, [index]: dataUrl }));
    } catch (error) {
      console.error('Error fetching photo:', error);
      setImageError(prev => ({ ...prev, [index]: true }));
    } finally {
      setLoadingImages(prev => ({ ...prev, [index]: false }));
    }
  };

  useEffect(() => {
    // Load current photo
    if (photos && photos[currentPhotoIndex] && !imageDataUrls[currentPhotoIndex]) {
      fetchPhoto(photos[currentPhotoIndex], currentPhotoIndex);
    }
  }, [currentPhotoIndex, photos]);

  // Cleanup URLs on unmount
  useEffect(() => {
    return () => {
      Object.values(imageDataUrls).forEach(url => {
        if (url) URL.revokeObjectURL(url);
      });
    };
  }, []);

  const goToNext = () => {
    if (currentPhotoIndex < photos.length - 1) {
      setCurrentPhotoIndex(currentPhotoIndex + 1);
    }
  };

  const goToPrevious = () => {
    if (currentPhotoIndex > 0) {
      setCurrentPhotoIndex(currentPhotoIndex - 1);
    }
  };

  const currentPhoto = photos[currentPhotoIndex];
  const isLoading = loadingImages[currentPhotoIndex];
  const hasError = imageError[currentPhotoIndex];
  const imageUrl = imageDataUrls[currentPhotoIndex];

  return (
    <div
      className={`fixed inset-0 bg-gradient-to-br from-black/60 via-black/50 to-black/70 backdrop-blur-lg flex flex-col z-50 transition-all duration-300 ${
        isFullscreen ? 'p-0' : 'p-3 sm:p-4'
      }`}
      tabIndex={0}
      onKeyDown={handleKeyDown}
    >
      {/* Header with elegant controls */}
      <div className={`flex justify-between items-center flex-shrink-0 transition-all duration-300 ${
        isFullscreen ? 'absolute top-4 left-4 right-4 z-10 opacity-0 hover:opacity-100' : 'mb-2 sm:mb-4'
      }`}>
        <div className="flex items-center space-x-4">
          <div className="bg-white items-center gap-x-3 backdrop-blur-md rounded-2xl px-4 py-2">
            <span className="text-black/90 text-sm font-medium">
              {currentPhotoIndex + 1} / {photos.length}
            </span>
          </div>
          <div className='bg-white text-black px-4 py-2 rounded-2xl'>
            <h3 className="text-sm font-medium truncate">Foto Surat - {suratInfo?.asal_instansi}</h3>
          </div>
        </div>

        <div className="flex items-center space-x-2">
          {/* Fullscreen toggle button */}
          {imageUrl && !isLoading && !hasError && (
            <button
              onClick={toggleFullscreen}
              className="group bg-white backdrop-blur-md hover:bg-blue-50 p-3 rounded-2xl border border-white/20 hover:border-blue-400/30 transition-all duration-300 ease-out"
              title={isFullscreen ? "Keluar dari fullscreen (F)" : "Mode fullscreen (F)"}
            >
              {isFullscreen ? (
                <Minimize2 className="h-5 w-5 text-blue-400 group-hover:text-blue-500 transition-colors" />
              ) : (
                <Maximize2 className="h-5 w-5 text-blue-400 group-hover:text-blue-500 transition-colors" />
              )}
            </button>
          )}

          <button
            onClick={onClose}
            className="group bg-white backdrop-blur-md hover:bg-red-50 p-3 rounded-2xl border border-white/20 hover:border-red-400/30 transition-all duration-300 ease-out"
            title="Tutup (Esc)"
          >
            <X className="h-5 w-5 text-red-400 group-hover:text-red-500 transition-colors" />
          </button>
        </div>
      </div>

      {/* Main Photo Container */}
      <div className={`flex-1 relative flex items-center justify-center min-h-0 overflow-hidden transition-all duration-300 ${
        isFullscreen ? 'mb-0' : 'mb-4'
      }`}>
        {isLoading ? (
          <div className="flex flex-col items-center space-y-4 text-white">
            <div className="relative">
              <RefreshCw className="animate-spin h-12 w-12 text-blue-400" />
              <div className="absolute inset-0 h-12 w-12 rounded-full border-2 border-blue-400/20 animate-pulse"></div>
            </div>
            <div className="bg-white/10 backdrop-blur-md rounded-2xl px-6 py-3 border border-white/20">
              <span className="text-white/90 font-medium">Memuat foto...</span>
            </div>
          </div>
        ) : hasError ? (
          <div className="text-center">
            <div className="bg-white/10 backdrop-blur-md rounded-3xl p-8 border border-white/20 max-w-md mx-auto">
              <div className="relative mb-6">
                <AlertCircle className="mx-auto h-16 w-16 text-red-400" />
                <div className="absolute inset-0 h-16 w-16 mx-auto rounded-full border-2 border-red-400/20 animate-ping"></div>
              </div>
              <h3 className="text-white text-xl font-semibold mb-2">Gagal memuat foto</h3>
              <p className="text-white/60 text-sm mb-6">{currentPhoto?.filename}</p>
              <button
                onClick={() => fetchPhoto(currentPhoto, currentPhotoIndex)}
                className="bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white px-6 py-3 rounded-2xl font-medium transition-all duration-300 ease-out hover:scale-105 hover:shadow-lg hover:shadow-blue-500/25"
              >
                Coba Lagi
              </button>
            </div>
          </div>
        ) : imageUrl ? (
          <div className="relative group w-full h-full flex items-center justify-center p-4">
            <div className="relative">
              <img
                src={imageUrl}
                alt={currentPhoto?.filename}
                className={`object-contain rounded-2xl shadow-lg transition-all duration-300 ease-out z-50 cursor-pointer ${
                  isFullscreen
                    ? 'max-w-screen max-h-screen rounded-none shadow-2xl'
                    : 'bg-white p-5 max-w-full max-h-full group-hover:scale-[1.01]'
                }`}
                style={isFullscreen ? {} : { maxHeight: 'calc(100vh - 200px)', maxWidth: 'calc(100vw - 120px)' }}
                onDoubleClick={handleImageDoubleClick}
                title="Double-click untuk fullscreen"
              />

              {/* Fullscreen hint overlay */}
              {!isFullscreen && (
                <div className=" absolute inset-0 w-fit h-fit">
                  <div className="bg-black/30 backdrop-blur-sm rounded-xl px-4 py-2 text-white text-sm font-medium">
                    Double-click untuk fullscreen
                  </div>
                </div>
              )}
            </div>

            {/* Elegant shadow overlay */}
            <div className={`absolute inset-0 shadow-2xl pointer-events-none opacity-20 ${
              isFullscreen ? 'rounded-none' : 'rounded-3xl'
            }`}></div>
          </div>
        ) : (
          <div className="bg-white/10 backdrop-blur-md rounded-3xl p-12 border border-white/20">
            <div className="text-center text-white/80">
              <Image className="mx-auto h-16 w-16 mb-4 opacity-50" />
              <p className="text-lg font-medium">Tidak ada foto</p>
            </div>
          </div>
        )}
      </div>

      {/* Modern Thumbnail Strip - Hide in fullscreen */}
      {photos.length > 1 && !isFullscreen && (
        <div className="transition-all duration-300">
          <div className="flex justify-center space-x-2 overflow-x-auto">
            {photos.map((photo, index) => (
              <button
                key={photo.id}
                onClick={() => setCurrentPhotoIndex(index)}
                className={`group relative flex-shrink-0 w-14 h-14 rounded-xl overflow-hidden transition-all duration-300 ease-out ${
                  index === currentPhotoIndex
                    ? 'border-1 border-blue-400 ring-offset-2 ring-offset-transparent scale-110 shadow-lg'
                    : 'hover:scale-105 opacity-60 hover:opacity-100'
                }`}
              >
                <div className="w-full h-full bg-white backdrop-blur-sm border border-white/20 rounded-xl flex items-center justify-center transition-all duration-300">
                  <Image className={`h-5 w-5 transition-colors ${
                    index === currentPhotoIndex
                      ? 'text-blue-400'
                      : 'text-black/70 group-hover:text-black'
                  }`} />
                </div>

                {/* Active indicator */}
                {index === currentPhotoIndex && (
                  <div className="absolute inset-0 rounded-xl border-1 border-blue-400/50 animate-pulse"></div>
                )}

                {/* Hover glow effect */}
                <div className="absolute inset-0 rounded-xl bg-gradient-to-t from-blue-500/0 to-blue-500/0 group-hover:from-blue-500/10 group-hover:to-blue-500/5 transition-all duration-300"></div>
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default PhotoGalleryModal;