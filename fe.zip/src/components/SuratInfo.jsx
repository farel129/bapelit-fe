import { Image } from "lucide-react";

const SuratInfo = ({ surat, onOpenPhotos }) => {
  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('id-ID', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    })
  }
console.log('DATA SURAT:', surat);

  return (
    <div className="bg-white shadow rounded-lg p-6">
      <h2 className="text-lg font-medium text-blue-500 mb-4">Informasi Surat</h2>
      <div className="space-y-3">
        <div>
          <label className="block text-sm font-medium text-gray-700">Nomor Surat</label>
          <p className="text-sm text-gray-900">{surat.nomor_surat}</p>
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700">Asal Instansi</label>
          <p className="text-sm text-gray-900">{surat.asal_instansi}</p>
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700">Tanggal Surat </label>
          <p className="text-sm text-gray-900">{formatDate(surat.created_at)}</p>
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700">Diterima Tanggal</label>
          <p className="text-sm text-gray-900">{formatDate(surat.processed_at)}</p>
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700">Tujuan Jabatan</label>
          <p className="text-sm text-gray-900">{surat.tujuan_jabatan}</p>
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700">Sifat Surat</label>
          <p className="text-sm text-gray-900">{surat.sifat}</p>
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700">Perihal</label>
          <p className="text-sm text-gray-900">{surat.perihal}</p>
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700">Dengan hormat harap</label>
          <p className="text-sm text-gray-900">{surat.tindakan}</p>
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700">Keterangan</label>
          <p className="text-sm text-gray-900">{surat.keterangan}</p>
        </div>
        
        <div>
          <label className="block text-sm font-medium text-gray-700">Status</label>
          <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${
            surat.status === 'pending' 
              ? 'bg-yellow-100 text-yellow-800' 
              : 'bg-green-100 text-green-800'
          }`}>
            {surat.status === 'pending' ? 'Menunggu' : 'Diproses'}
          </span>
        </div>
        {/* Photo Actions */}
          {surat.has_photos && surat.photos && surat.photos.length > 0 && (
            <div className=" block flex-col space-y-2">
              <button
                onClick={() => {
                  console.log('Opening photos for surat:', surat.id);
                  console.log('Photos:', surat.photos);
                  onOpenPhotos({ photos: surat.photos, info: surat });
                }}
                className="flex items-center space-x-2 px-3 py-2 bg-green-100 text-green-700 rounded-lg hover:bg-green-200 transition-colors"
              >
                <Image className="h-4 w-4" />
                <span className="text-sm font-medium">
                  Lihat Foto ({surat.photo_count})
                </span>
              </button>
            </div>
          )}
      </div>
      
    </div>
  )
}

export default SuratInfo