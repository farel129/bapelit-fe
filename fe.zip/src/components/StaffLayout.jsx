import { useState } from 'react'
import { Link, useLocation } from 'react-router-dom'
import { useAuth } from '../contexts/AuthContext'
import {
  Home,
  User,
  LogOut,
  Menu,
  X,
  Database,
  Users,
  Bell
} from 'lucide-react'
import img from '../assets/img/logobapelit.png'

const AdminLayout = ({ children }) => {
  const { user, logout } = useAuth()
  const location = useLocation()
  const [sidebarOpen, setSidebarOpen] = useState(false)

  const navigation = [
    { name: 'Dashboard', href: '/staff', icon: Home },
    { name: 'Semua Data', href: '/staff-semua-data', icon: Database },
    { name: 'Daftar User', href: '/staff-list-user', icon: Users },
    { name: 'Notifikasi', href: '/staff-notifications', icon: Bell },
  ]

  const isActive = (path) => location.pathname === path

  return (
    <div className="min-h-screen bg-gray-50/50">
      {/* Mobile sidebar */}
      <div className={`fixed inset-0 z-50 lg:hidden ${sidebarOpen ? 'block' : 'hidden'}`}>
        <div className="fixed inset-0 bg-gray-600 bg-opacity-75" onClick={() => setSidebarOpen(false)} />
        <div className="fixed inset-y-0 left-0 w-64 bg-white shadow-xl">
          <div className="flex items-center justify-between h-16 px-4 border-b">
            <h1 className="text-xl font-bold text-gray-800">Sistem Surat</h1>
            <button onClick={() => setSidebarOpen(false)}>
              <X className="w-6 h-6" />
            </button>
          </div>
          <nav className="mt-5 px-2">
            {navigation.map((item) => (
              <Link
                key={item.name}
                to={item.href}
                className={`group flex items-center px-2 py-2 text-base font-medium rounded-md mb-1 ${isActive(item.href)
                  ? 'bg-[#cfcfcf] text-black'
                  : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
                  }`}
                onClick={() => setSidebarOpen(false)}
              >
                <item.icon className="mr-4 h-6 w-6" />
                {item.name}
              </Link>
            ))}
          </nav>
          <div className='px-4 mt-2'>
              <button
                onClick={logout}
                className="flex items-center space-x-1 cursor-pointer text-sm font-semibold text-red-400 hover:text-red-600"
              >
                <LogOut className="w-4 h-4" />
                <span>Logout</span>
              </button>
            </div>
        </div>
      </div>

      {/* Desktop sidebar */}
      <div className="hidden lg:fixed lg:inset-y-0 lg:flex lg:w-50 lg:flex-col">
        <div className="flex-1 flex flex-col min-h-0 bg-white pt-3">
          <div className=" flex flex-col pt-5 pb-4 overflow-y-auto">
            <div className="flex items-center flex-shrink-0 px-4">
              <img src={img} alt="" className='w-5 mr-2 grayscale' />
              <h1 className="text-xl font-bold text-gray-900">DISPOMA</h1>
            </div>
            <nav className="mt-5 flex-1 px-2 space-y-3">
              {navigation.map((item) => (
                <Link
                  key={item.name}
                  to={item.href}
                  className={`group flex items-center px-4 py-3 text-xs rounded-xl ${isActive(item.href)
                    ? 'bg-[#262628] text-white'
                    : 'text-gray-400 hover:bg-gray-50 hover:text-gray-900'
                    }`}
                >
                  <item.icon className="mr-3 h-3 w-3" />
                  {item.name}
                </Link>
              ))}
            </nav>
            <div className='px-4 mt-7'>
              <button
                onClick={logout}
                className="flex items-center space-x-1 cursor-pointer text-sm font-semibold text-red-400 hover:text-red-600"
              >
                <LogOut className="w-4 h-4" />
                <span>Logout</span>
              </button>
            </div>

          </div>
        </div>
      </div>

      {/* Main content */}
      <div className="lg:pl-50 flex flex-col flex-1">
        {/* Top bar */}
        <div className="sticky top-0 bg-white pt-3 z-30">
          <div className="flex items-center justify-between h-16 px-4">
            <button
              className="lg:hidden"
              onClick={() => setSidebarOpen(true)}
            >
              <Menu className="w-6 h-6" />
            </button>

            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <User className="w-5 h-5 text-gray-400" />
                <span className="text-sm font-medium text-gray-700">
                  {user?.name} ({user?.jabatan})
                </span>
              </div>

            </div>
          </div>
        </div>

        {/* Page content */}
        <main className="flex-1 px-4 lg:px-8 bg-white min-h-screen">
          {children}
        </main>
      </div>
    </div>
  )
}

export default AdminLayout