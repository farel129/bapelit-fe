import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import toast from 'react-hot-toast'
import { Send, Building2, User, FileText, Sparkles, Camera, X, Eye, Plus, StickyNote, CheckCircle2, Upload, UserCircle2, BookPlus, Mail, Pencil, LetterText, ArrowUp, BookOpen, ArrowRight, CheckCircle } from 'lucide-react'
import { api } from '../utils/api'
import Admin from '../assets/img/admin_buatsurat.png'

const AdminBuatSurat = () => {
  const [formData, setFormData] = useState({
    asal_instansi: '',
    nomor_surat: '',
    tujuan_jabatan: '',
    keterangan: ''
  })
  const [disposisiData, setDisposisiData] = useState({
    perihal: '',
    disposisi_kepada: '',
    tindakan: '',
    sifat: '',
    catatan: ''
  })
  const [selectedFiles, setSelectedFiles] = useState([])
  const [previewUrls, setPreviewUrls] = useState([])
  const [loading, setLoading] = useState(false)
  const [focusedField, setFocusedField] = useState(null)
  const [previewModal, setPreviewModal] = useState({ isOpen: false, imageUrl: '', index: null })
  const [isTutorialModalOpen, setIsTutorialModalOpen] = useState(false);

  const closeTutorialModal = () => {
    setIsTutorialModalOpen(false);
  }; const [currentStep, setCurrentStep] = useState(0);


  const steps = [
    {
      icon: <FileText className="w-5 h-5" />,
      title: "Lengkapi Data Surat Masuk",
      description: "Isi kolom 'Asal Instansi', 'Nomor Surat', pilih 'Tujuan Jabatan', dan tambahkan 'Keterangan'.",
      color: "from-blue-500 to-blue-600"
    },
    {
      icon: <Upload className="w-5 h-5" />,
      title: "Upload Foto Surat",
      description: "Klik area upload atau tombol 'Tambah Foto' untuk memilih dan mengunggah gambar surat. Maksimal 10 foto dengan ukuran masing-masing maksimal 5MB.",
      color: "from-emerald-500 to-emerald-600"
    },
    {
      icon: <BookOpen className="w-5 h-5" />,
      title: "Isi Lembar Disposisi",
      description: "Masukkan 'Perihal', pilih 'Disposisi Kepada', pilih satu atau lebih 'Tindakan', tentukan 'Sifat', dan tambahkan 'Catatan' jika diperlukan.",
      color: "from-purple-500 to-purple-600"
    },
    {
      icon: <Send className="w-5 h-5" />,
      title: "Kirim Dokumen",
      description: "Setelah semua data lengkap, klik tombol 'Kirim Surat & Disposisi' di bagian bawah halaman.",
      color: "from-[#262628] to-black"
    }
  ];

  const nextStep = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1);
    }
  };

  const prevStep = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const navigate = useNavigate()

  const jabatanOptions = [
    'Sekretaris',
    'Kasubag Umum dan Kepegawaian',
    'Kasubag Keuangan',
    'Kabid Pendanaan, Pengendalian, dan Evaluasi',
    'Kabid Pemerintahan dan Pembangunan Manusia',
    'Kabid Perekonomian, Infrastruktur, dan Kewilayahan',
    'Kabid Penelitian dan Pengembangan'
  ]

  const MAX_FILES = 10
  const MAX_FILE_SIZE = 5 * 1024 * 1024 // 5MB

  const handleSubmit = async (e) => {
    e.preventDefault()
    setLoading(true)

    try {
      const submitData = new FormData()
      // Data surat
      submitData.append('asal_instansi', formData.asal_instansi)
      submitData.append('nomor_surat', formData.nomor_surat)
      submitData.append('tujuan_jabatan', formData.tujuan_jabatan)
      submitData.append('keterangan', formData.keterangan)
      // Data disposisi
      submitData.append('perihal', disposisiData.perihal)
      submitData.append('disposisi_kepada', disposisiData.disposisi_kepada)
      submitData.append('tindakan', disposisiData.tindakan)
      submitData.append('sifat', disposisiData.sifat)
      submitData.append('catatan', disposisiData.catatan)
      // Foto
      selectedFiles.forEach((file) => {
        submitData.append('photos', file)
      })

      await api.post('/surat-masuk', submitData)
      toast.success('Surat masuk & lembar disposisi berhasil dibuat!')
      navigate('/admin')
    } catch (error) {
      toast.error(error.response?.data?.error || 'Gagal membuat surat masuk')
    } finally {
      setLoading(false)
    }
  }

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    })
  }

  const handleDisposisiChange = (e) => {
    setDisposisiData({
      ...disposisiData,
      [e.target.name]: e.target.value
    })
  }

  const validateFile = (file) => {
    const allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp']
    if (!allowedTypes.includes(file.type)) {
      toast.error(`File ${file.name}: Hanya file gambar (JPEG, PNG, GIF, WEBP) yang diizinkan!`)
      return false
    }

    if (file.size > MAX_FILE_SIZE) {
      toast.error(`File ${file.name}: Ukuran file maksimal 5MB!`)
      return false
    }

    return true
  }

  const handleFileChange = (e) => {
    const files = Array.from(e.target.files)

    if (files.length === 0) return

    // Cek apakah total file akan melebihi batas
    if (selectedFiles.length + files.length > MAX_FILES) {
      toast.error(`Maksimal ${MAX_FILES} foto yang dapat diupload!`)
      return
    }

    const validFiles = files.filter(validateFile)

    if (validFiles.length === 0) return

    // Tambahkan file baru ke array yang sudah ada
    const newSelectedFiles = [...selectedFiles, ...validFiles]
    setSelectedFiles(newSelectedFiles)

    // Generate preview URLs untuk file baru
    const newPreviewUrls = [...previewUrls]

    validFiles.forEach((file, index) => {
      const reader = new FileReader()
      reader.onload = (e) => {
        newPreviewUrls[selectedFiles.length + index] = e.target.result
        setPreviewUrls([...newPreviewUrls])
      }
      reader.readAsDataURL(file)
    })

    // Reset input file
    e.target.value = ''
  }

  const removeFile = (index) => {
    const newSelectedFiles = selectedFiles.filter((_, i) => i !== index)
    const newPreviewUrls = previewUrls.filter((_, i) => i !== index)

    setSelectedFiles(newSelectedFiles)
    setPreviewUrls(newPreviewUrls)
  }

  const openPreviewModal = (imageUrl, index) => {
    setPreviewModal({ isOpen: true, imageUrl, index })
  }

  const closePreviewModal = () => {
    setPreviewModal({ isOpen: false, imageUrl: '', index: null })
  }

  const tindakanOptions = [
    "Tanggapan dan Saran",
    "Wakili / Hadir / Terima",
    "Mendampingi Saya",
    "Untuk Ditindaklanjuti",
    "Pelajari / Telaa'h / Sarannya",
    "Untuk Dikaji Sesuai dengan Ketentuan",
    "Untuk Dibantu / Dipertimbangkan / Sesuai dengan Ketentuan",
    "Selesaikan / Proses Sesuai Ketentuan",
    "Monitor Realisasinya / Perkembangannya",
    "Siapkan Pointers / Sambutan / Bahan",
    "Menghadap / Informasinya",
    "Membaca / File / Referensi",
    "Agendakan / Jadwalkan / Koordinasikan"
  ]
  const [selectedTindakan, setSelectedTindakan] = useState([])
  // ...existing code...
  const onTindakanChange = (option, e) => {
    let newSelected
    if (selectedTindakan.includes(option)) {
      newSelected = selectedTindakan.filter((item) => item !== option)
    } else {
      newSelected = [...selectedTindakan, option]
    }
    setSelectedTindakan(newSelected)
    setDisposisiData({
      ...disposisiData,
      tindakan: newSelected.join(', ')
    })
  }

  const onRemoveTindakan = (option, e) => {
    e.stopPropagation()
    const newSelected = selectedTindakan.filter((item) => item !== option)
    setSelectedTindakan(newSelected)
    setDisposisiData({
      ...disposisiData,
      tindakan: newSelected.join(', ')
    })
  }

  return (
    <div className="min-h-screen ">


      <div className="relative">
        {/* Header */}
        <div className="flex justify-between bg-gradient-to-bl from-gray-100 to-indigo-500/20 p-5 rounded-2xl mb-6 overflow-hidden">
          <div className='flex flex-col gap-y-2 '>
            <h1 className="text-xl font-bold text-[#262628]">Buat Surat dan Lembar disposisi</h1>
            <div className='flex relative'>
              <div className="inline-flex items-center rounded-full justify-center w-10 h-10 bg-gray-300 shadow-lg">
                <Mail className="w-4 h-4 text-[#262628]" />
              </div>
              <div className="inline-flex absolute ml-7 items-center rounded-full justify-center w-10 h-10 bg-[#fff] shadow-lg">
                <Pencil className="w-4 h-4 text-[#262628]" />
              </div>
            </div>
            <div className='mt-3'>
              {/* Di dalam div className='mt-3' */}
              <button
                onClick={() => setIsTutorialModalOpen(true)}
                className='bg-white p-3 rounded-full shadow-lg h-fit font-medium text-gray-500 hover:text-black text-sm cursor-pointer'
              >
                <p>Lihat Tutorial?</p>
              </button>
              <p className='text-xs text-gray-600 animate-pulse max-w-60 mt-3'>tekan tombol untuk melihat tutorial</p>
            </div>
          </div>
          <div className='flex gap-x-3'>


            <div className='w-50 h-full relative flex items-center'>
              <div className='w-50 h-50 bg-[#262628] absolute rounded-full'></div>
              <div className='w-10 self-start h-10 bg-[#999999] absolute rounded-full animate-bounce flex justify-center items-center'><LetterText className='text-white w-6 h-6' /></div>
              <div className='w-full rounded-2xl bg-gradient-to-bl from-gray-100/5 to-pink-500/20 backdrop-blur-sm bottom-0 h-[20%] absolute z-1'></div>
              <img src={Admin} alt="" className='z-10' />
            </div>
          </div>
        </div>

        <div className="grid lg:grid-cols-2 gap-5">
          {/* LEFT: Form Surat */}
          <div className="space-y-5">
            <div className=" bg-white rounded-2xl shadow-lg overflow-hidden border border-black/10">
              {/* Header Card */}
              <div className="relative p-5">
                <div className="absolute inset-0 bg-gradient-to-br from-white/10 to-transparent"></div>
                <div className="relative flex items-center space-x-4">
                  <div className="w-12 h-12 bg-[#5c4444] rounded-xl flex items-center justify-center">
                    <Mail className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h2 className="text-lg font-bold text-[#262628]">Data Surat Masuk</h2>
                    <p className="text-gray-500 text-xs">Lengkapi informasi surat masuk dengan teliti</p>
                  </div>
                </div>
              </div>

              {/* Form Content */}
              <div className="p-8">
                <form id="surat-form" onSubmit={handleSubmit} className="space-y-8">
                  {/* Asal Instansi */}
                  <div className="group">
                    <label className="flex items-center text-sm font-semibold text-slate-800 mb-4">
                      <div className="w-10 h-10 bg-[#fff] rounded-xl flex items-center justify-center mr-2 shadow-lg">
                        <Building2 className="w-5 h-5 text-[#292929]" />
                      </div>
                      Asal Instansi
                    </label>
                    <div className="relative">
                      <input
                        type="text"
                        name="asal_instansi"
                        required
                        value={formData.asal_instansi}
                        onChange={handleChange}
                        onFocus={() => setFocusedField('asal_instansi')}
                        onBlur={() => setFocusedField(null)}
                        className={`w-full px-6 py-4 text-slate-800 bg-white/70 backdrop-blur-sm border-2 rounded-2xl transition-all duration-300 outline-none placeholder-slate-400  ${focusedField === 'asal_instansi'
                          ? 'border-purple-400 shadow-2xl shadow-purple-200/50 ring-4 ring-purple-100/50 bg-white scale-[1.02]'
                          : 'border-slate-200/60 hover:border-purple-300 hover:shadow-lg'
                          }`}
                        placeholder="Contoh: Dinas Pendidikan Kota Tasikmalaya"
                      />
                      <div className={`absolute inset-0 rounded-2xl bg-gradient-to-r from-purple-400/5 to-blue-400/5 pointer-events-none transition-opacity duration-300 ${focusedField === 'asal_instansi' ? 'opacity-100' : 'opacity-0'
                        }`} />
                    </div>
                  </div>

                  {/* Nomor Surat */}
                  <div className="group">
                    <label className="flex items-center text-sm font-semibold text-slate-800 mb-4">
                      <div className="w-10 h-10 bg-[#fff] rounded-xl flex items-center justify-center mr-2 shadow-lg">
                        <FileText className="w-5 h-5 text-[#292929]" />
                      </div>
                      Nomor Surat
                    </label>
                    <div className="relative">
                      <input
                        type="text"
                        name="nomor_surat"
                        required
                        value={formData.nomor_surat}
                        onChange={handleChange}
                        onFocus={() => setFocusedField('nomor_surat')}
                        onBlur={() => setFocusedField(null)}
                        className={`w-full px-6 py-4 text-slate-800 bg-white/70 backdrop-blur-sm border-2 rounded-2xl transition-all duration-300 outline-none placeholder-slate-400  ${focusedField === 'nomor_surat'
                          ? 'border-purple-400 shadow-2xl shadow-purple-200/50 ring-4 ring-purple-100/50 bg-white scale-[1.02]'
                          : 'border-slate-200/60 hover:border-purple-300 hover:shadow-lg'
                          }`}
                        placeholder="Contoh: 123/ABC/2024"
                      />
                    </div>
                  </div>

                  {/* Tujuan Jabatan */}
                  <div className="group">
                    <label className="flex items-center text-sm font-semibold text-slate-800 mb-4">
                      <div className="w-10 h-10 bg-[#fff] rounded-xl flex items-center justify-center mr-2 shadow-lg">
                        <User className="w-5 h-5 text-[#292929]" />
                      </div>
                      Tujuan Jabatan
                    </label>
                    <div className="relative">
                      <select
                        name="tujuan_jabatan"
                        required
                        value={formData.tujuan_jabatan}
                        onChange={handleChange}
                        onFocus={() => setFocusedField('tujuan_jabatan')}
                        onBlur={() => setFocusedField(null)}
                        className={`w-full px-6 py-4 text-slate-800 bg-white/70 backdrop-blur-sm border-2 rounded-2xl transition-all duration-300 outline-none appearance-none cursor-pointer  ${focusedField === 'tujuan_jabatan'
                          ? 'border-purple-400 shadow-2xl shadow-purple-200/50 ring-4 ring-purple-100/50 bg-white scale-[1.02]'
                          : 'border-slate-200/60 hover:border-purple-300 hover:shadow-lg'
                          }`}
                      >
                        <option value="" className="text-slate-400">Pilih jabatan tujuan...</option>
                        {jabatanOptions.map((jabatan) => (
                          <option key={jabatan} value={jabatan} className="text-slate-800 ">
                            {jabatan}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>

                  {/* Keterangan */}
                  <div className="group">
                    <label className="flex items-center text-sm font-semibold text-slate-800 mb-4">
                      <div className="w-10 h-10 bg-[#fff] rounded-xl flex items-center justify-center mr-2 shadow-lg">
                        <FileText className="w-5 h-5 text-[#292929]" />
                      </div>
                      Keterangan
                    </label>
                    <div className="relative">
                      <textarea
                        name="keterangan"
                        required
                        rows={5}
                        value={formData.keterangan}
                        onChange={handleChange}
                        onFocus={() => setFocusedField('keterangan')}
                        onBlur={() => setFocusedField(null)}
                        className={`w-full px-6 py-4 text-slate-800 bg-white/70 backdrop-blur-sm border-2 rounded-2xl transition-all duration-300 outline-none resize-none placeholder-slate-400  ${focusedField === 'keterangan'
                          ? 'border-purple-400 shadow-2xl shadow-purple-200/50 ring-4 ring-purple-100/50 bg-white scale-[1.02]'
                          : 'border-slate-200/60 hover:border-purple-300 hover:shadow-lg'
                          }`}
                        placeholder="Jelaskan keperluan atau isi surat secara singkat dan jelas..."
                      />
                    </div>
                  </div>

                  {/* Upload Foto */}
                  <div className="group">
                    <label className="flex items-center text-sm font-semibold text-slate-800 mb-4">
                      <div className="w-10 h-10 bg-[#fff] rounded-xl flex items-center justify-center mr-2 shadow-lg">
                        <Camera className="w-5 h-5 text-[#292929]" />
                      </div>
                      Foto Surat
                      <span className="ml-3 px-3 py-1 bg-gradient-to-r from-purple-100 to-blue-100 text-purple-700 rounded-full text-xs font-bold">
                        {selectedFiles.length}/{MAX_FILES}
                      </span>
                    </label>

                    <div className="relative">
                      <input
                        type="file"
                        id="photos"
                        name="photos"
                        accept="image/*"
                        multiple
                        onChange={handleFileChange}
                        className="hidden"
                      />

                      {selectedFiles.length === 0 ? (
                        <label
                          htmlFor="photos"
                          className="group w-full flex flex-col items-center justify-center px-8 py-16 text-slate-600 backdrop-blur-sm bg-gradient-to-br from-white/60 to-purple-50/40 border-2 border-dashed border-purple-200 rounded-3xl cursor-pointer transition-all duration-300 hover:from-purple-50/60 hover:to-blue-50/60 hover:border-purple-400 hover:shadow-2xl hover:shadow-purple-500/10"
                        >
                          <div className="relative mb-6">
                            <div className="w-10 h-10 flex justify-center items-center rounded-lg shadow-2xl shadow-purple-500/30 group-hover:scale-110 transition-transform duration-300">
                              <Upload className="w-6 h-16 text-[#262628]" />
                            </div>
                            <div className="absolute -top-2 -right-2 w-6 h-6 bg-gradient-to-br from-emerald-400 to-emerald-600 rounded-full flex items-center justify-center">
                              <Plus className="w-3 h-3 text-white" />
                            </div>
                          </div>
                          <span className=" font-bold text-slate-800 mb-3">Upload Foto Surat</span>
                          <span className="text-sm text-slate-500 text-center leading-relaxed">
                            Klik untuk memilih file atau drag & drop
                            <br />
                            <span className="text-xs ">JPEG, PNG, GIF, WEBP (Maks. 5MB per file, {MAX_FILES} foto)</span>
                          </span>
                        </label>
                      ) : (
                        <div className="space-y-6">
                          <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                            {previewUrls.map((previewUrl, index) => (
                              <div key={index} className="group relative">
                                <div className="aspect-square bg-gradient-to-br from-white to-slate-50 rounded-2xl overflow-hidden border-2 border-slate-200/60 shadow-xl hover:shadow-2xl transition-all duration-300 hover:scale-105">
                                  <img
                                    src={previewUrl}
                                    alt={`Preview ${index + 1}`}
                                    className="w-full h-full object-cover"
                                  />
                                </div>

                                <div className="absolute -top-2 -right-2 flex space-x-2 opacity-0 group-hover:opacity-100 transition-opacity duration-200">
                                  <button
                                    type="button"
                                    onClick={() => openPreviewModal(previewUrl, index)}
                                    className="w-8 h-8 bg-[#456462] text-white rounded-xl flex items-center justify-center hover:scale-110 transition-transform duration-200 shadow-lg"
                                  >
                                    <Eye className="w-4 h-4" />
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => removeFile(index)}
                                    className="w-8 h-8 bg-gradient-to-br from-red-500 to-red-600 text-white rounded-xl flex items-center justify-center hover:scale-110 transition-transform duration-200 shadow-lg"
                                  >
                                    <X className="w-4 h-4" />
                                  </button>
                                </div>

                                <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent text-white p-3 rounded-b-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                                  <p className="text-xs  truncate">{selectedFiles[index]?.name}</p>
                                  <p className="text-xs text-slate-300">
                                    {(selectedFiles[index]?.size / 1024 / 1024).toFixed(1)} MB
                                  </p>
                                </div>
                              </div>
                            ))}

                            {selectedFiles.length < MAX_FILES && (
                              <label
                                htmlFor="photos"
                                className="group aspect-square backdrop-blur-sm bg-gradient-to-br from-white/60 to-purple-50/40 border-2 border-dashed border-purple-200 rounded-2xl cursor-pointer hover:from-purple-50/60 hover:to-blue-50/60 hover:border-purple-400 transition-all duration-300 flex flex-col items-center justify-center text-slate-500 shadow-lg hover:shadow-xl"
                              >
                                <div className="p-4 bg-[#5c4444] rounded-xl shadow-lg group-hover:scale-110 transition-transform duration-200 mb-3">
                                  <Plus className="w-6 h-6 text-white" />
                                </div>
                                <span className="text-xs font-bold text-slate-700">Tambah</span>
                                <span className="text-xs text-slate-500">Foto</span>
                              </label>
                            )}
                          </div>

                          <div className="backdrop-blur-sm bg-gradient-to-r from-purple-50/80 to-blue-50/80 rounded-2xl p-6 border border-purple-100">
                            <div className="flex items-center justify-between text-sm">
                              <div className="flex items-center space-x-3">
                                <CheckCircle2 className="w-6 h-6 text-emerald-500" />
                                <span className="font-bold text-slate-800">
                                  {selectedFiles.length} foto berhasil dipilih
                                </span>
                              </div>
                              <span className=" text-slate-600 px-3 py-1 bg-white/60 rounded-lg">
                                Total: {(selectedFiles.reduce((total, file) => total + file.size, 0) / 1024 / 1024).toFixed(1)} MB
                              </span>
                            </div>
                            {selectedFiles.length >= MAX_FILES && (
                              <div className="flex items-center space-x-2 mt-3">
                                <div className="w-2 h-2 bg-amber-400 rounded-full animate-pulse" />
                                <p className="text-xs text-amber-700 ">
                                  Batas maksimal {MAX_FILES} foto tercapai
                                </p>
                              </div>
                            )}
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>

          {/* RIGHT: Form Lembar Disposisi */}
          <div className="space-y-8">
            <div className="backdrop-blur-xl bg-white shadow-lg rounded-2xl overflow-hidden border border-black/10">
              {/* Header Card */}
              <div className="relative p-5">
                <div className="absolute inset-0 bg-gradient-to-br from-white/10 to-transparent"></div>
                <div className="relative flex items-center space-x-4">
                  <div className="w-12 h-12 bg-[#456462] backdrop-blur-sm rounded-xl flex items-center justify-center">
                    <FileText className="w-6 h-6 text-[#fff]" />
                  </div>
                  <div>
                    <h2 className="text-lg font-bold text-[#262628]">Lembar Disposisi</h2>
                    <p className="text-gray-500 text-xs">Isi informasi disposisi dengan lengkap</p>
                  </div>
                </div>
              </div>

              {/* Form Content */}
              <div className="p-8 space-y-8">
                {/* Perihal */}
                <div className="group">
                  <label className="flex items-center text-sm font-semibold text-slate-800 mb-4">
                    <div className="w-10 h-10 rounded-xl flex items-center justify-center mr-3 shadow-lg ">
                      <StickyNote className="w-5 h-5 text-[#262628]" />
                    </div>
                    Perihal
                  </label>
                  <input
                    type="text"
                    name="perihal"
                    value={disposisiData.perihal}
                    onChange={handleDisposisiChange}
                    className="w-full px-6 py-4 rounded-2xl bg-white/70 backdrop-blur-sm focus:border-blue-400 border-2 border-slate-200/60 focus:bg-white focus:shadow-2xl focus:shadow-blue-200/50 outline-none  transition-all duration-300 placeholder-slate-400 hover:border-blue-300 hover:shadow-lg"
                    placeholder="Perihal surat/disposisi"
                  />
                </div>

                {/* Disposisi Kepada */}
                <div className="group">
                  <label className="flex items-center text-sm font-semibold text-slate-800 mb-4">
                    <div className="w-10 h-10 rounded-xl flex items-center justify-center mr-3 shadow-lg ">
                      <UserCircle2 className="w-5 h-5 text-[#262628]" />
                    </div>
                    Disposisi Kepada
                  </label>
                  <select
                    name="disposisi_kepada"
                    required
                    value={disposisiData.disposisi_kepada}
                    onChange={handleDisposisiChange}
                    className="w-full px-6 py-4 text-slate-800 border-2 border-slate-200/60 bg-white/70 backdrop-blur-sm rounded-2xl transition-all duration-300 outline-none appearance-none cursor-pointer  hover:border-blue-300 focus:border-blue-400 focus:shadow-2xl focus:shadow-blue-200/50"
                  >
                    <option value="" className="text-slate-400">Pilih jabatan tujuan...</option>
                    {jabatanOptions.map((jabatan) => (
                      <option key={jabatan} value={jabatan} className="text-slate-800 ">
                        {jabatan}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Tindakan */}
                <div className="group">
                  <label className="flex items-center text-sm font-semibold text-slate-800 mb-4">
                    <div className="w-10 h-10 rounded-xl flex items-center justify-center mr-3 shadow-lg ">
                      <Sparkles className="w-5 h-5 text-[#262628]" />
                    </div>
                    Tindakan
                  </label>

                  {selectedTindakan.length > 0 && (
                    <div className="flex flex-wrap gap-3 p-6 bg-gradient-to-r from-blue-50/80 to-indigo-50/80 backdrop-blur-sm rounded-2xl border border-blue-200/50 mb-6">
                      {selectedTindakan.map((tindakan, index) => (
                        <span
                          key={index}
                          className="inline-flex items-center px-4 py-2 rounded-xl text-sm bg-[#456462] text-white shadow-lg hover:shadow-xl transition-all duration-200 hover:scale-105"
                        >
                          {tindakan}
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation()
                              onRemoveTindakan(tindakan, e)
                            }}
                            className="ml-3 inline-flex items-center justify-center w-5 h-5 rounded-full bg-white/20 hover:bg-white/30 transition-all duration-200 group"
                          >
                            <X className="w-3 h-3 group-hover:rotate-90 transition-transform duration-200" />
                          </button>
                        </span>
                      ))}
                    </div>
                  )}

                  <div className="border-2 border-slate-200/60 rounded-2xl overflow-hidden bg-white/70 backdrop-blur-sm shadow-lg">
                    <div className="max-h-72 overflow-y-auto">
                      {tindakanOptions.map((option, index) => (
                        <div
                          key={index}
                          className={`flex items-center p-5 hover:bg-blue-50/50 transition-all duration-200 cursor-pointer border-b border-slate-100/80 last:border-b-0 group ${selectedTindakan.includes(option) ? 'bg-blue-50/70' : ''
                            }`}
                          onClick={(e) => {
                            if (e.target.type !== 'checkbox') {
                              onTindakanChange(option, e)
                            }
                          }}
                        >
                          <div className="relative">
                            <input
                              type="checkbox"
                              checked={selectedTindakan.includes(option)}
                              onChange={(e) => onTindakanChange(option, e)}
                              className="w-5 h-5 text-[#456462] border-2 border-slate-300 rounded-lg focus:ring-[#456462] focus:ring-2 focus:ring-offset-0 transition-all duration-200"
                            />
                          </div>
                          <label className="ml-4 text-sm text-slate-700 cursor-pointer select-none flex-1 group-hover:text-[#456462] transition-colors duration-200">
                            {option}
                          </label>
                          <div className="w-2 h-2 rounded-full bg-[#456462] opacity-0 group-hover:opacity-100 transition-opacity duration-200"></div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Sifat */}
                <div className="group">
                  <label className="flex items-center text-sm font-semibold text-slate-800 mb-4">
                    <div className="w-10 h-10 rounded-xl flex items-center justify-center mr-3 shadow-lg ">
                      <Sparkles className="w-5 h-5 text-[#262628]" />
                    </div>
                    Sifat
                  </label>
                  <div className="grid grid-cols-3 gap-4">
                    {['Sangat Segera', 'Segera', 'Rahasia'].map((sifat) => (
                      <label key={sifat} className="relative">
                        <input
                          type="radio"
                          name="sifat"
                          value={sifat}
                          checked={disposisiData.sifat === sifat}
                          onChange={handleDisposisiChange}
                          className="sr-only"
                        />
                        <div className={`p-4 text-center rounded-2xl border-2 cursor-pointer transition-all duration-300  text-sm shadow-lg hover:shadow-xl ${disposisiData.sifat === sifat
                          ? 'border-blue-500 bg-gradient-to-br from-blue-50 to-blue-100 text-blue-700 shadow-blue-200/50'
                          : 'border-slate-200/60 bg-white/70 backdrop-blur-sm text-slate-600 hover:border-blue-300 hover:bg-blue-50/30'
                          }`}>
                          <span>{sifat}</span>
                        </div>
                      </label>
                    ))}
                  </div>
                </div>

                {/* Catatan */}
                <div className="group">
                  <label className="flex items-center text-sm font-semibold text-slate-800 mb-4">
                    <div className="w-10 h-10 rounded-xl flex items-center justify-center mr-3 shadow-lg ">
                      <StickyNote className="w-5 h-5 text-[#262628]" />
                    </div>
                    Catatan
                  </label>
                  <textarea
                    name="catatan"
                    value={disposisiData.catatan}
                    onChange={handleDisposisiChange}
                    rows={4}
                    className="w-full px-6 py-4 rounded-2xl bg-white/70 backdrop-blur-sm focus:border-blue-400 border-2 border-slate-200/60 focus:bg-white focus:shadow-2xl focus:shadow-blue-200/50 outline-none  resize-none transition-all duration-300 placeholder-slate-400 hover:border-blue-300 hover:shadow-lg"
                    placeholder="Catatan tambahan untuk disposisi"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Submit Button */}
        <div className="mt-7 mb-7 flex justify-center">
          <button
            type="submit"
            form="surat-form"
            disabled={loading}
            className="group relative px-6 py-3 cursor-pointer bg-[#262628] text-white font-semibold rounded-lg shadow-lg transition-all duration-300 transform disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:scale-100"
          >
            {loading ? (
              <div className="flex items-center justify-center space-x-4">
                <div className="w-6 h-6 border-3 border-white border-t-transparent rounded-full animate-spin" />
                <span>Mengirim Data...</span>
              </div>
            ) : (
              <div className="flex items-center justify-center space-x-2">
                <Send className="w-4 h-4 group-hover:translate-x-1 transition-transform duration-300" />
                <span>Kirim Surat & Disposisi</span>
                {selectedFiles.length > 0 && (
                  <div className="px-4 py-2 bg-white/20 backdrop-blur-sm rounded-full text-sm font-bold">
                    {selectedFiles.length} foto
                  </div>
                )}
              </div>
            )}
          </button>
        </div>
      </div>

      {/* Modal Preview Foto */}
      {previewModal.isOpen && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="relative max-w-6xl max-h-full">
            {/* Header Modal */}
            <div className="absolute -top-20 left-0 right-0 flex items-center justify-between text-white">
              <div className="flex items-center space-x-4">
                {previewModal.index !== null && (
                  <div className="px-6 py-3 bg-white/10 backdrop-blur-sm rounded-2xl border border-white/20">
                    <span className="text-sm ">
                      Foto {previewModal.index + 1} dari {selectedFiles.length}
                    </span>
                  </div>
                )}
              </div>
              <button
                onClick={closePreviewModal}
                className="p-4 bg-white/10 backdrop-blur-sm rounded-2xl hover:bg-white/20 transition-colors duration-200 border border-white/20"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            {/* Image Container */}
            <div className="bg-white/5 backdrop-blur-sm rounded-xl p-2 border border-white/10 shadow-2xl">
              <img
                src={previewModal.imageUrl}
                alt="Preview Full"
                className="max-w-full max-h-[50vh] object-contain rounded-2xl shadow-2xl"
              />
            </div>
          </div>
        </div>
      )}

      {/* Modal Tutorial */}
      {isTutorialModalOpen && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4 animate-in fade-in duration-300">
          <div className="relative bg-white backdrop-blur-sm rounded-3xl shadow-2xl max-w-2xl w-full flex flex-col">
            {/* Header */}
            <div className="relative flex items-center justify-between p-5 pb-4">
              <div className="flex items-center space-x-3">
                <div className="relative">
                  <div className="w-10 h-10 bg-white rounded-2xl flex items-center justify-center shadow-lg">
                    <Sparkles className="w-6 h-6 text-[262628]" />
                  </div>
                  <div className="absolute -top-1 -right-1 w-4 h-4 bg-emerald-400 rounded-full animate-pulse"></div>
                </div>
                <div>
                  <h3 className="text-lg font-bold bg-gradient-to-r from-gray-800 to-gray-600 bg-clip-text text-transparent">
                    Tutorial Interaktif
                  </h3>
                  <p className="text-sm text-gray-500 mt-1">Buat Surat dan Lembar Disposisi</p>
                </div>
              </div>
              <button
                onClick={closeTutorialModal}
                className="p-3 rounded-2xl text-gray-400 hover:bg-gray-100 hover:text-gray-600 transition-all duration-200 group"
                aria-label="Tutup"
              >
                <X className="w-6 h-6 group-hover:rotate-90 transition-transform duration-200" />
              </button>
            </div>

            {/* Progress Bar */}
            <div className="px-8 pb-4">
              <div className="flex items-center justify-between mb-3">
                <span className="text-sm font-medium text-gray-600">
                  Langkah {currentStep + 1} dari {steps.length}
                </span>
                <span className="text-sm text-gray-500">
                  {Math.round(((currentStep + 1) / steps.length) * 100)}% selesai
                </span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2 overflow-hidden">
                <div 
                  className="h-full bg-gradient-to-r from-blue-500 to-purple-600 rounded-full transition-all duration-500 ease-out"
                  style={{ width: `${((currentStep + 1) / steps.length) * 100}%` }}
                ></div>
              </div>
            </div>

            {/* Content */}
            <div className="flex-grow px-8 pb-4">
              <div className="relative">
                {/* Step Indicators */}
                

                {/* Current Step Content */}
                <div className="text-center space-y-6 animate-in fade-in slide-in-from-right-4 duration-500" key={currentStep}>
                  <div className="flex justify-center">
                    <div className={`w-12 h-12 bg-gradient-to-br ${steps[currentStep].color} rounded-3xl flex items-center justify-center shadow-lg transform hover:scale-105 transition-transform duration-200`}>
                      <div className="text-white">
                        {steps[currentStep].icon}
                      </div>
                    </div>
                  </div>
                  
                  <div className="space-y-4">
                    <h4 className="text-lg font-bold text-gray-800">
                      {steps[currentStep].title}
                    </h4>
                    <p className="text-gray-600 leading-relaxed max-w-md mx-auto">
                      {steps[currentStep].description}
                    </p>
                  </div>
                </div>
                <div className="flex justify-center mt-5">
                  <div className="flex space-x-4">
                    {steps.map((_, index) => (
                      <div
                        key={index}
                        className={`w-2 h-2 rounded-full transition-all duration-300 ${
                          index === currentStep
                            ? 'bg-[#262628] scale-125'
                            : index < currentStep
                            ? 'bg-emerald-500 scale-110'
                            : 'bg-gray-300'
                        }`}
                      />
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* Navigation Footer */}
            <div className="flex items-center justify-between p-5 border-t border-gray-100/50">
              <button
                onClick={prevStep}
                disabled={currentStep === 0}
                className={`px-6 py-3 rounded-2xl font-medium transition-all duration-200 ${
                  currentStep === 0
                    ? 'text-gray-400 cursor-not-allowed'
                    : 'text-gray-600 hover:bg-gray-100 hover:text-gray-800'
                }`}
              >
                Sebelumnya
              </button>

              <div className="flex space-x-3">
                {currentStep < steps.length - 1 ? (
                  <button
                    onClick={nextStep}
                    className="px-8 py-3 bg-[#262628] text-sm text-white rounded-2xl font-medium hover:shadow-lg flex items-center space-x-2 group"
                  >
                    <span>Selanjutnya</span>
                    <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform duration-200" />
                  </button>
                ) : (
                  <button
                    onClick={closeTutorialModal}
                    className="px-8 py-3 bg-gradient-to-r text-sm from-emerald-600 to-blue-600 text-white rounded-2xl font-medium hover:shadow-lg transition-all duration-200 transform hover:scale-105 flex items-center space-x-2"
                  >
                    <CheckCircle className="w-4 h-4" />
                    <span>Selesai</span>
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

export default AdminBuatSurat