import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { useAuth } from '../contexts/AuthContext'
import axios from 'axios'
import { Mail, FileText, Clock, CheckCircle, Eye, Plus, BellDot, LayoutDashboard, Download, Loader2, AlertCircle, Building, Calendar, User, FileCheck, Sparkles } from 'lucide-react'
import { api } from '../utils/api'
import { toast } from 'react-hot-toast'

const StaffDashboard = () => {
  const [dashboardData, setDashboardData] = useState(null)
  const [notifications, setNotifications] = useState([])
  const [loading, setLoading] = useState(true)
  const [isDownloading, setIsDownloading] = useState(false)
  const [downloadProgress, setDownloadProgress] = useState(0)
  const [downloadingSuratId, setDownloadingSuratId] = useState(null)
  const { user } = useAuth()

  useEffect(() => {
    fetchDashboardData()
    fetchNotifications()
  }, [])

  // Fetch dashboard stats dan forwarded surat
  const fetchDashboardData = async () => {
    try {
      const response = await api.get('/dashboard/forwarded-surat')
      setDashboardData(response.data)
      console.log('Dashboard data:', response.data)
    } catch (error) {
      console.error('Error fetching dashboard data:', error)
      toast.error('Gagal memuat data dashboard')
    }
  }

  // Fetch notifications untuk surat yang diforward
  const fetchNotifications = async () => {
    try {
      const response = await api.get('/notifications/staff?limit=50')
      setNotifications(response.data.notifications || [])
      console.log('Notifications:', response.data.notifications)
    } catch (error) {
      console.error('Error fetching notifications:', error)
      toast.error('Gagal memuat notifikasi')
    } finally {
      setLoading(false)
    }
  }

  // Mark notification sebagai dibaca
  const markAsRead = async (notificationId) => {
    try {
      await api.put(`/notifications/staff/${notificationId}/read`)
      // Update state lokal
      setNotifications(prev => 
        prev.map(notif => 
          notif.id === notificationId 
            ? { ...notif, is_read: true }
            : notif
        )
      )
      // Update dashboard stats
      if (dashboardData) {
        setDashboardData(prev => ({
          ...prev,
          statistics: {
            ...prev.statistics,
            unread: Math.max(0, prev.statistics.unread - 1)
          }
        }))
      }
      toast.success('Ditandai sebagai dibaca')
    } catch (error) {
      console.error('Error marking as read:', error)
      toast.error('Gagal menandai sebagai dibaca')
    }
  }

  // Mark all notifications as read
  const markAllAsRead = async () => {
    try {
      await api.put('/notifications/staff/mark-all-read')
      
      // Update state lokal
      setNotifications(prev => 
        prev.map(notif => ({ ...notif, is_read: true }))
      )
      
      // Update dashboard stats
      if (dashboardData) {
        setDashboardData(prev => ({
          ...prev,
          statistics: {
            ...prev.statistics,
            unread: 0
          }
        }))
      }
      
      toast.success('Semua notifikasi ditandai sebagai dibaca')
    } catch (error) {
      console.error('Error marking all as read:', error)
      toast.error('Gagal menandai semua sebagai dibaca')
    }
  }

  const getStatusColor = (status) => {
    switch (status) {
      case 'pending':
        return 'bg-gray-100 text-gray-900 border-gray-300'
      case 'processed':
        return 'bg-black text-white border-black'
      case 'forwarded':
        return 'bg-gray-800 text-white border-gray-800'
      default:
        return 'bg-gray-50 text-gray-600 border-gray-200'
    }
  }

  const getSifatColor = (sifat) => {
    switch (sifat?.toLowerCase()) {
      case 'segera':
        return 'bg-black text-white border-black shadow-lg'
      case 'penting':
        return 'bg-gray-700 text-white border-gray-700 shadow-md'
      case 'biasa':
        return 'bg-gray-200 text-gray-800 border-gray-300'
      default:
        return 'bg-gray-100 text-gray-600 border-gray-200'
    }
  }

  const formatDate = (dateString) => {
    if (!dateString) return '-'
    return new Date(dateString).toLocaleDateString('id-ID', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    })
  }

  const formatDateShort = (dateString) => {
    if (!dateString) return '-'
    return new Date(dateString).toLocaleDateString('id-ID', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    })
  }

  const handleDownloadPDF = async (suratId, nomorSurat) => {
    setIsDownloading(true)
    setDownloadingSuratId(suratId)
    setDownloadProgress(0)

    try {
      const response = await api.get(`/surat/${suratId}/pdf`, {
        responseType: 'blob',
        onDownloadProgress: (progressEvent) => {
          const total = progressEvent.total
          const current = progressEvent.loaded
          if (total) {
            const percentage = Math.round((current / total) * 100)
            setDownloadProgress(percentage)
          }
        }
      })

      // Create blob URL and download
      const url = window.URL.createObjectURL(new Blob([response.data]))
      const link = document.createElement('a')
      link.href = url
      link.setAttribute('download', `disposisi-${nomorSurat || suratId}.pdf`)
      document.body.appendChild(link)
      link.click()
      link.remove()
      window.URL.revokeObjectURL(url)

      toast.success('PDF berhasil diunduh!')

    } catch (err) {
      console.error('Error downloading PDF:', err)
      toast.error('Gagal mengunduh PDF')
    } finally {
      setIsDownloading(false)
      setDownloadProgress(0)
      setDownloadingSuratId(null)
    }
  }

  const handleViewSurat = async (notificationId, suratId) => {
    // Mark as read ketika dibuka jika belum dibaca
    if (notificationId && notifications.find(n => n.id === notificationId && !n.is_read)) {
      await markAsRead(notificationId)
    }
  }

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="relative">
          <div className="animate-spin rounded-full h-16 w-16 border-4 border-gray-200"></div>
          <div className="animate-spin rounded-full h-16 w-16 border-4 border-black border-t-transparent absolute top-0 left-0"></div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen">
      <div className=" mx-auto space-y-8">
        {/* Header Section */}
        <div className="flex justify-between items-center">
          <div className='flex gap-x-4 items-center'>
            <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-black via-gray-800 to-gray-600 rounded-2xl shadow-lg border border-gray-200">
              <LayoutDashboard className="w-8 h-8 text-white" />
            </div>
            <div>
              <h1 className="text-4xl font-light tracking-wide text-black mb-1">Dashboard</h1>
              <p className="text-sm text-gray-500 font-medium">Selamat datang, <span className="text-black font-semibold">{user?.nama}</span> • {user?.jabatan}</p>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <Sparkles className="w-5 h-5 text-gray-400" />
            <span className="text-sm text-gray-400 font-medium">Executive Dashboard</span>
          </div>
        </div>

        {/* Elegant Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="group relative bg-white backdrop-blur-lg rounded-3xl shadow-lg border border-gray-100 overflow-hidden hover:shadow-lg transition-all duration-500 hover:-translate-y-1">
            <div className="absolute inset-0 bg-gradient-to-br from-gray-50 to-white opacity-50"></div>
            <div className="relative p-8">
              <div className="flex items-center justify-between mb-4">
                <div className="p-3 bg-black rounded-2xl shadow-lg">
                  <FileText className="h-6 w-6 text-white" />
                </div>
                <div className="w-2 h-2 rounded-full bg-black animate-pulse"></div>
              </div>
              <div className="space-y-2">
                <p className="text-sm font-medium text-gray-500 uppercase tracking-wider">
                  Total Surat Diterima
                </p>
                <p className="text-3xl font-light text-black tracking-tight">
                  {dashboardData?.statistics?.total || 0}
                </p>
              </div>
            </div>
          </div>

          <div className="group relative bg-white backdrop-blur-lg rounded-3xl shadow-lg border border-gray-100 overflow-hidden hover:shadow-lg transition-all duration-500 hover:-translate-y-1">
            <div className="absolute inset-0 bg-gradient-to-br from-gray-50 to-white opacity-50"></div>
            <div className="relative p-8">
              <div className="flex items-center justify-between mb-4">
                <div className="p-3 bg-gray-800 rounded-2xl shadow-lg">
                  <BellDot className="h-6 w-6 text-white" />
                </div>
                <div className="w-2 h-2 rounded-full bg-gray-800 animate-pulse"></div>
              </div>
              <div className="space-y-2">
                <p className="text-sm font-medium text-gray-500 uppercase tracking-wider">
                  Belum Dibaca
                </p>
                <p className="text-3xl font-light text-black tracking-tight">
                  {dashboardData?.statistics?.unread || 0}
                </p>
              </div>
            </div>
          </div>

          <div className="group relative bg-white backdrop-blur-lg rounded-3xl shadow-lg border border-gray-100 overflow-hidden hover:shadow-lg transition-all duration-500 hover:-translate-y-1">
            <div className="absolute inset-0 bg-gradient-to-br from-gray-50 to-white opacity-50"></div>
            <div className="relative p-8">
              <div className="flex items-center justify-between mb-4">
                <div className="p-3 bg-gray-700 rounded-2xl shadow-lg">
                  <Calendar className="h-6 w-6 text-white" />
                </div>
                <div className="w-2 h-2 rounded-full bg-gray-700 animate-pulse"></div>
              </div>
              <div className="space-y-2">
                <p className="text-sm font-medium text-gray-500 uppercase tracking-wider">
                  Hari Ini
                </p>
                <p className="text-3xl font-light text-black tracking-tight">
                  {dashboardData?.statistics?.today || 0}
                </p>
              </div>
            </div>
          </div>

          <div className="group relative bg-white backdrop-blur-lg rounded-3xl shadow-lg border border-gray-100 overflow-hidden hover:shadow-lg transition-all duration-500 hover:-translate-y-1">
            <div className="absolute inset-0 bg-gradient-to-br from-gray-50 to-white opacity-50"></div>
            <div className="relative p-8">
              <div className="flex items-center justify-between mb-4">
                <div className="p-3 bg-gray-600 rounded-2xl shadow-lg">
                  <Clock className="h-6 w-6 text-white" />
                </div>
                <div className="w-2 h-2 rounded-full bg-gray-600 animate-pulse"></div>
              </div>
              <div className="space-y-2">
                <p className="text-sm font-medium text-gray-500 uppercase tracking-wider">
                  Pending
                </p>
                <p className="text-3xl font-light text-black tracking-tight">
                  {dashboardData?.statistics?.pending || 0}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Refined Quick Actions */}
        <div className="relative bg-white backdrop-blur-xl rounded-3xl shadow-lg border border-gray-100 overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-r from-gray-50 via-white to-gray-50 opacity-50"></div>
          <div className="relative p-8">
            <h3 className="text-xl font-light text-black mb-6 flex items-center tracking-wide">
              <div className="p-2 bg-black rounded-xl mr-4 shadow-lg">
                <FileCheck className="w-5 h-5 text-white" />
              </div>
              Aksi Cepat
            </h3>
            <div className="flex flex-wrap gap-4">
              <button
                onClick={markAllAsRead}
                disabled={!notifications.some(n => !n.is_read)}
                className="group relative inline-flex items-center px-8 py-4 bg-black hover:bg-gray-800 text-white font-medium rounded-2xl shadow-lg transition-all duration-300 hover:shadow-lg hover:-translate-y-0.5 disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:translate-y-0"
              >
                <CheckCircle className="w-5 h-5 mr-3" />
                <span>Tandai Semua Dibaca ({notifications.filter(n => !n.is_read).length})</span>
                <div className="absolute inset-0 rounded-2xl bg-white opacity-0 group-hover:opacity-10 transition-opacity duration-300"></div>
              </button>
              
              <button
                onClick={() => {
                  fetchNotifications()
                  fetchDashboardData()
                  toast.success('Data berhasil dimuat ulang')
                }}
                className="group relative inline-flex items-center px-8 py-4 bg-white hover:bg-gray-50 text-black font-medium rounded-2xl shadow-lg border border-gray-200 transition-all duration-300 hover:shadow-lg hover:-translate-y-0.5"
              >
                <BellDot className="w-5 h-5 mr-3" />
                <span>Refresh Data</span>
                <div className="absolute inset-0 rounded-2xl bg-black opacity-0 group-hover:opacity-5 transition-opacity duration-300"></div>
              </button>
            </div>
          </div>
        </div>

        {/* Luxurious Table */}
        <div className="relative bg-white backdrop-blur-xl rounded-3xl shadow-lg border border-gray-100 overflow-hidden mb-10">
          <div className="absolute inset-0 bg-gradient-to-br from-white via-gray-50 to-white opacity-50"></div>
          <div className="relative">
            <div className="px-8 py-6 border-b border-gray-100 bg-gradient-to-r from-gray-50 via-white to-gray-50">
              <div className="flex justify-between items-center">
                <h2 className="text-2xl font-light text-black flex items-center tracking-wide">
                  <div className="p-3 bg-black rounded-2xl mr-4 shadow-lg">
                    <Mail className="w-6 h-6 text-white" />
                  </div>
                  Surat yang Diteruskan ke Anda
                </h2>
                <div className="flex items-center gap-4">
                  <span className="text-sm text-gray-500 font-medium">
                    Total: <span className="text-black font-semibold">{notifications.length}</span> surat
                  </span>
                  {dashboardData?.statistics?.unread > 0 && (
                    <span className="inline-flex items-center px-4 py-2 rounded-full text-xs font-semibold bg-black text-white shadow-lg">
                      {dashboardData.statistics.unread} baru
                    </span>
                  )}
                </div>
              </div>
            </div>
            
            <div className="overflow-x-auto">
              <table className="min-w-full">
                <thead>
                  <tr className="bg-gradient-to-r from-gray-50 to-white border-b border-gray-100">
                    <th className="px-8 py-4 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Status</th>
                    <th className="px-8 py-4 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Nomor Surat</th>
                    <th className="px-8 py-4 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Asal Instansi</th>
                    <th className="px-8 py-4 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Perihal</th>
                    <th className="px-8 py-4 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Sifat</th>
                    <th className="px-8 py-4 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Pesan Forward</th>
                    <th className="px-8 py-4 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Tanggal</th>
                    <th className="px-8 py-4 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Aksi</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-50">
                  {notifications.map((notification, index) => (
                    <tr 
                      key={notification.id} 
                      className={`group transition-all duration-300 ${
                        !notification.is_read 
                          ? 'bg-gradient-to-r from-gray-50 to-white border-l-4 border-black shadow-lg' 
                          : 'hover:bg-gradient-to-r hover:from-gray-25 hover:to-white'
                      }`}
                    >
                      <td className="px-8 py-6">
                        <div className="flex items-center">
                          {!notification.is_read ? (
                            <div className="flex items-center">
                              <div className="w-3 h-3 bg-black rounded-full mr-3 shadow-lg"></div>
                              <span className="inline-flex items-center px-3 py-1.5 rounded-full text-xs font-semibold bg-black text-white shadow-lg">
                                Baru
                              </span>
                            </div>
                          ) : (
                            <div className="flex items-center">
                              <CheckCircle className="w-4 h-4 text-gray-400 mr-3" />
                              <span className="inline-flex items-center px-3 py-1.5 rounded-full text-xs font-medium bg-gray-100 text-gray-700 border border-gray-200">
                                Dibaca
                              </span>
                            </div>
                          )}
                        </div>
                      </td>
                      <td className="px-8 py-6">
                        <div className="text-sm font-semibold text-black">
                          {notification.surat_masuk?.nomor_surat || '-'}
                        </div>
                        <div className="text-xs text-gray-500 mt-1">
                          {formatDateShort(notification.surat_masuk?.created_at)}
                        </div>
                      </td>
                      <td className="px-8 py-6">
                        <div className="flex items-center">
                          <Building className="w-4 h-4 text-gray-400 mr-3" />
                          <div>
                            <div className="text-sm font-medium text-black">
                              {notification.surat_masuk?.asal_instansi || '-'}
                            </div>
                            <div className="text-xs text-gray-500 mt-1">
                              → {notification.surat_masuk?.tujuan_jabatan}
                            </div>
                          </div>
                        </div>
                      </td>
                      <td className="px-8 py-6">
                        <div className="text-sm text-black max-w-xs">
                          <div className="font-medium truncate" title={notification.surat_masuk?.perihal}>
                            {notification.surat_masuk?.perihal || '-'}
                          </div>
                          {notification.surat_masuk?.keterangan && (
                            <div className="text-xs text-gray-500 mt-1 truncate" title={notification.surat_masuk?.keterangan}>
                              {notification.surat_masuk?.keterangan}
                            </div>
                          )}
                        </div>
                      </td>
                      <td className="px-8 py-6">
                        {notification.surat_masuk?.sifat ? (
                          <span className={`inline-flex items-center px-4 py-2 rounded-full text-xs font-semibold border ${getSifatColor(notification.surat_masuk?.sifat)}`}>
                            {notification.surat_masuk?.sifat}
                          </span>
                        ) : (
                          <span className="text-xs text-gray-400">-</span>
                        )}
                      </td>
                      <td className="px-8 py-6">
                        <div className="text-sm text-black max-w-xs">
                          <div className="truncate" title={notification.message}>
                            {notification.message}
                          </div>
                        </div>
                      </td>
                      <td className="px-8 py-6 text-sm text-black">
                        <div className="flex items-center">
                          <Calendar className="w-4 h-4 text-gray-400 mr-2" />
                          {formatDate(notification.created_at)}
                        </div>
                      </td>
                      <td className="px-8 py-6">
                        <div className="flex items-center space-x-3">
                          <Link
                            to={`/staff-process/${notification.surat_id}`}
                            onClick={() => handleViewSurat(notification.id, notification.surat_id)}
                            className="group inline-flex items-center px-4 py-2 bg-black hover:bg-gray-800 text-white text-xs font-medium rounded-xl shadow-lg transition-all duration-300 hover:shadow-lg hover:-translate-y-0.5"
                          >
                            <Eye className="w-3 h-3 mr-2" />
                            Lihat
                          </Link>
                          
                          <button
                            onClick={() => handleDownloadPDF(notification.surat_id, notification.surat_masuk?.nomor_surat)}
                            disabled={isDownloading && downloadingSuratId === notification.surat_id}
                            className="group inline-flex items-center px-4 py-2 bg-gray-800 hover:bg-gray-700 text-white text-xs font-medium rounded-xl shadow-lg transition-all duration-300 hover:shadow-lg hover:-translate-y-0.5 disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:translate-y-0"
                            title="Download PDF"
                          >
                            {isDownloading && downloadingSuratId === notification.surat_id ? (
                              <>
                                <Loader2 className="w-3 h-3 mr-2 animate-spin" />
                                <span className="text-xs">
                                  {downloadProgress > 0 ? `${downloadProgress}%` : 'Loading...'}
                                </span>
                              </>
                            ) : (
                              <>
                                <Download className="w-3 h-3 mr-2" />
                                PDF
                              </>
                            )}
                          </button>

                          {!notification.is_read && (
                            <button
                              onClick={() => markAsRead(notification.id)}
                              className="group inline-flex items-center px-4 py-2 bg-gray-600 hover:bg-gray-500 text-white text-xs font-medium rounded-xl shadow-lg transition-all duration-300 hover:shadow-lg hover:-translate-y-0.5"
                              title="Tandai sebagai dibaca"
                            >
                              <CheckCircle className="w-3 h-3 mr-2" />
                              Baca
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                  
                  {notifications.length === 0 && (
                    <tr>
                      <td colSpan="8" className="px-8 py-16 text-center text-gray-500">
                        <div className="flex flex-col items-center space-y-6">
                          <div className="w-24 h-24 bg-gradient-to-br from-gray-100 to-gray-200 rounded-full flex items-center justify-center shadow-lg">
                            <Mail className="w-12 h-12 text-gray-400" />
                          </div>
                          <div>
                            <h3 className="text-xl font-light text-black mb-2">Tidak ada surat</h3>
                            <p className="text-sm text-gray-500">
                              Belum ada surat yang diteruskan ke Anda saat ini.
                            </p>
                          </div>
                        </div>
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default StaffDashboard