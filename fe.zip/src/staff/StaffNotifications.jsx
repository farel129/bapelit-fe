import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import axios from 'axios'
import toast from 'react-hot-toast'
import { Bell, Eye, CheckCircle, BellDot, Calendar, Mail, Clock, User, Building, FileText, Sparkles, RefreshCw, Award } from 'lucide-react'
import { api } from '../utils/api'

const StaffNotifications = () => {
  const [notifications, setNotifications] = useState([])
  const [loading, setLoading] = useState(true)
  const [refreshing, setRefreshing] = useState(false)
  const [stats, setStats] = useState({
    total: 0,
    unread: 0,
    today: 0,
    read: 0
  })

  useEffect(() => {
    fetchNotifications()
  }, [])

  const fetchNotifications = async (showRefreshToast = false) => {
    try {
      if (showRefreshToast) {
        setRefreshing(true)
        toast.loading('Memuat notifikasi...')
      }

      const response = await api.get('/notifications')
      const notificationData = response.data || []
      setNotifications(notificationData)
      
      // Calculate stats
      const total = notificationData.length
      const unread = notificationData.filter(n => !n.is_read).length
      const today = notificationData.filter(n => {
        const notifDate = new Date(n.created_at).toDateString()
        const todayDate = new Date().toDateString()
        return notifDate === todayDate
      }).length
      const read = total - unread

      setStats({ total, unread, today, read })

      if (showRefreshToast) {
        toast.dismiss()
        toast.success(`Berhasil memuat ${total} notifikasi`)
      }

    } catch (error) {
      console.error('Error fetching notifications:', error)
      toast.error('Gagal memuat notifikasi')
    } finally {
      setLoading(false)
      setRefreshing(false)
    }
  }

  const markAsRead = async (notificationId) => {
    try {
      await api.put(`/notifications/${notificationId}/read`)
      setNotifications(notifications.map(notif =>
        notif.id === notificationId ? { ...notif, is_read: true } : notif
      ))
      
      // Update stats
      setStats(prev => ({
        ...prev,
        unread: Math.max(0, prev.unread - 1),
        read: prev.read + 1
      }))
      
      toast.success('Ditandai sebagai dibaca')
    } catch (error) {
      console.error('Error marking as read:', error)
      toast.error('Gagal menandai notifikasi sebagai dibaca')
    }
  }

  const markAllAsRead = async () => {
    try {
      const unreadNotifications = notifications.filter(n => !n.is_read)
      if (unreadNotifications.length === 0) {
        toast.info('Semua notifikasi sudah dibaca')
        return
      }

      // Mark all unread notifications as read (assuming there's an endpoint for this)
      await api.put('/notifications/mark-all-read')
      
      setNotifications(notifications.map(notif => ({ ...notif, is_read: true })))
      setStats(prev => ({
        ...prev,
        unread: 0,
        read: prev.total
      }))
      
      toast.success('Semua notifikasi ditandai sebagai dibaca')
    } catch (error) {
      console.error('Error marking all as read:', error)
      toast.error('Gagal menandai semua notifikasi sebagai dibaca')
    }
  }

  const formatDate = (dateString) => {
    if (!dateString) return '-'
    return new Date(dateString).toLocaleDateString('id-ID', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    })
  }

  const formatDateShort = (dateString) => {
    if (!dateString) return '-'
    return new Date(dateString).toLocaleDateString('id-ID', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    })
  }

  const getTimeAgo = (dateString) => {
    if (!dateString) return '-'
    const now = new Date()
    const notifDate = new Date(dateString)
    const diffInMs = now - notifDate
    const diffInMinutes = Math.floor(diffInMs / (1000 * 60))
    const diffInHours = Math.floor(diffInMs / (1000 * 60 * 60))
    const diffInDays = Math.floor(diffInMs / (1000 * 60 * 60 * 24))

    if (diffInMinutes < 60) {
      return `${diffInMinutes} menit yang lalu`
    } else if (diffInHours < 24) {
      return `${diffInHours} jam yang lalu`
    } else {
      return `${diffInDays} hari yang lalu`
    }
  }

  const handleRefresh = () => {
    fetchNotifications(true)
  }

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="relative">
          <div className="animate-spin rounded-full h-16 w-16 border-4 border-gray-200"></div>
          <div className="animate-spin rounded-full h-16 w-16 border-4 border-black border-t-transparent absolute top-0 left-0"></div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen">
      <div className="mx-auto space-y-8">
        {/* Header Section */}
        
        {/* Luxurious Notifications List */}
        <div className="relative bg-white rounded-3xl shadow-lg border border-gray-100 overflow-hidden mb-10">
          <div className="absolute inset-0 bg-gradient-to-br from-white via-gray-50 to-white opacity-50"></div>
          <div className="relative">
            <div className="px-8 py-6 border-b border-gray-100 bg-gradient-to-r from-gray-50 via-white to-gray-50">
              <div className="flex justify-between items-center">
                <h2 className="text-2xl font-light text-black flex items-center tracking-wide">
                  <div className="p-3 bg-black rounded-2xl mr-4 shadow-lg">
                    <Bell className="w-6 h-6 text-white" />
                  </div>
                  Daftar Notifikasi
                </h2>
                <div className="flex items-center gap-4">
                  <span className="text-sm text-gray-500 font-medium">
                    Total: <span className="text-black font-semibold">{notifications.length}</span> notifikasi
                  </span>
                  {stats.unread > 0 && (
                    <span className="inline-flex items-center px-4 py-2 rounded-full text-xs font-semibold bg-black text-white shadow-lg">
                      {stats.unread} baru
                    </span>
                  )}
                </div>
              </div>
            </div>

            {notifications.length === 0 ? (
              <div className="px-8 py-16 text-center text-gray-500">
                <div className="flex flex-col items-center space-y-6">
                  <div className="w-24 h-24 bg-gradient-to-br from-gray-100 to-gray-200 rounded-full flex items-center justify-center shadow-lg">
                    <Bell className="w-12 h-12 text-gray-400" />
                  </div>
                  <div>
                    <h3 className="text-xl font-light text-black mb-2">Tidak ada notifikasi</h3>
                    <p className="text-sm text-gray-500">
                      Belum ada notifikasi yang masuk saat ini.
                    </p>
                  </div>
                </div>
              </div>
            ) : (
              <div className="divide-y divide-gray-50">
                {notifications.map((notification, index) => (
                  <div
                    key={notification.id}
                    className={`group transition-all duration-300 px-8 py-6 ${
                      !notification.is_read 
                        ? 'bg-gradient-to-r from-gray-50 to-white border-l-4 border-black shadow-lg' 
                        : 'hover:bg-gradient-to-r hover:from-gray-25 hover:to-white'
                    }`}
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center mb-4">
                          {!notification.is_read ? (
                            <div className="flex items-center">
                              <div className="w-3 h-3 bg-black rounded-full mr-4 shadow-lg"></div>
                              <span className="inline-flex items-center px-3 py-1.5 rounded-full text-xs font-semibold bg-black text-white shadow-lg mr-4">
                                Baru
                              </span>
                            </div>
                          ) : (
                            <div className="flex items-center">
                              <CheckCircle className="w-4 h-4 text-gray-400 mr-4" />
                              <span className="inline-flex items-center px-3 py-1.5 rounded-full text-xs font-medium bg-gray-100 text-gray-700 border border-gray-200 mr-4">
                                Dibaca
                              </span>
                            </div>
                          )}
                          <div className="flex items-center text-xs text-gray-500">
                            <Calendar className="w-3 h-3 mr-1" />
                            {getTimeAgo(notification.created_at)}
                          </div>
                        </div>

                        <div className="space-y-3">
                          <div className="flex items-start">
                            <FileText className="w-5 h-5 text-gray-400 mr-4 mt-0.5 flex-shrink-0" />
                            <div>
                              <p className="text-sm font-medium text-black leading-relaxed">
                                {notification.message || 'Notifikasi tanpa pesan'}
                              </p>
                              {notification.description && (
                                <p className="text-xs text-gray-500 mt-1">
                                  {notification.description}
                                </p>
                              )}
                            </div>
                          </div>

                          <div className="flex items-center text-xs text-gray-500 ml-9">
                            <Clock className="w-3 h-3 mr-2" />
                            <span>{formatDate(notification.created_at)}</span>
                            {notification.surat_id && (
                              <>
                                <span className="mx-2">•</span>
                              </>
                            )}
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center space-x-3 ml-6">
                        {notification.surat_id && (
                          <Link
                            to={`/staff-process/${notification.surat_id}`}
                            className="group inline-flex items-center px-4 py-2 bg-black hover:bg-gray-800 text-white text-xs font-medium rounded-xl shadow-lg transition-all duration-300 hover:shadow-xl hover:-translate-y-0.5"
                            title="Lihat surat"
                          >
                            <Eye className="w-3 h-3 mr-2" />
                            Lihat
                          </Link>
                        )}
                        
                        {!notification.is_read && (
                          <button
                            onClick={() => markAsRead(notification.id)}
                            className="group inline-flex items-center px-4 py-2 bg-gray-600 hover:bg-gray-500 text-white text-xs font-medium rounded-xl shadow-lg transition-all duration-300 hover:shadow-xl hover:-translate-y-0.5"
                            title="Tandai sebagai dibaca"
                          >
                            <CheckCircle className="w-3 h-3 mr-2" />
                            Baca
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}

export default StaffNotifications