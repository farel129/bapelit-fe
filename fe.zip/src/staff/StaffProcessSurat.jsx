import { useParams, useNavigate } from 'react-router-dom'
import { CheckCircle, Download, Eye } from 'lucide-react'

// Custom hooks
import { useSuratDetail } from '../hooks/useSuratDetail'
import { useSuratProcessing } from '../hooks/useSuratProcessing'

// Components
import SuratInfo from '../components/SuratInfo'
import { useSuratMasuk } from '../hooks/useSuratMasuk'
import PhotoGalleryModal from '../components/PhotoGalleryModal'
import { useState } from 'react'
import { api } from '../utils/api'
import toast from 'react-hot-toast'


const StaffProcessSurat = () => {
  const { id } = useParams()
  const navigate = useNavigate() // Tambahkan useNavigate
  const [acceptLoading, setAcceptLoading] = useState(false);

  // Custom hooks
  const { surat, loading, updateSuratStatus } = useSuratDetail(id)

  const {
    handleDownloadPDF,
  } = useSuratProcessing(id, () => updateSuratStatus('processed'))


  const {
    selectedPhotos,
    setSelectedPhotos,
  } = useSuratMasuk()

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-gray-600"></div>
      </div>
    )
  }

  if (!surat) {
    return (
      <div className="text-center py-12">
        <p className="text-gray-500">Surat tidak ditemukan</p>
      </div>
    )
  }

  const handleAccept = async () => {
    setAcceptLoading(true);
    try {
      await api.post(`/surat/${id}/accept`, {
        atasan_jabatan: surat.disposisi_kepada
      });

      toast.success('Disposisi berhasil diterima');
      updateSuratStatus('processed'); // Update status surat

      // Redirect ke /staff setelah berhasil
      navigate('/staff');

    } catch (err) {
      toast.error('Gagal menerima disposisi');
    } finally {
      setAcceptLoading(false);
    }
  };

  return (
    <div className="">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex gap-x-3 items-center">
          <div className="inline-flex items-center justify-center w-10 h-10 bg-gradient-to-bl from-gray-500 to-gray-300 rounded-lg shadow-lg">
            <Eye className="w-6 h-6 text-white" />
          </div>
          <h1 className="text-2xl font-bold text-gray-500 uppercase">Disposisi Surat</h1>

        </div>
        {surat.status === 'processed' && (
          <button
            onClick={handleDownloadPDF}
            className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-gradient-to-bl from-gray-500 to-gray-300 hover:bg-gradient-to-bl hover:from-gray-500 hover:to-gray-500 cursor-pointer"
          >
            <Download className="w-4 h-4 mr-2" />
            Download PDF
          </button>
        )}


        {surat.jabatan !== surat.disposisi_kepada && !surat.processed_by && (
          <button
            onClick={handleAccept}
            disabled={acceptLoading || surat.processed_by} // Disable jika loading atau sudah ada processed_by
            className={`ml-4 inline-flex items-center px-4 py-2 border text-sm font-medium rounded-md ${acceptLoading || surat.processed_by
              ? 'border-gray-300 text-gray-400 bg-gray-100 cursor-not-allowed'
              : 'border-green-500 text-green-600 bg-white hover:bg-green-50 cursor-pointer'
              }`}
          >
            {acceptLoading ? (
              <span>Memproses...</span>
            ) : surat.processed_by ? (
              <>
                <CheckCircle className="w-4 h-4 mr-2" />
                Sudah Diterima
              </>
            ) : (
              <>
                <CheckCircle className="w-4 h-4 mr-2" />
                Terima Disposisi
              </>
            )}
          </button>
        )}
      </div>

      <div className="">
        <SuratInfo surat={surat} onOpenPhotos={setSelectedPhotos} />
      </div>

      {/* Photo Gallery Modal */}
      {selectedPhotos && (
        <PhotoGalleryModal
          photos={selectedPhotos.photos}
          suratInfo={selectedPhotos.info}
          onClose={() => setSelectedPhotos(null)}
        />
      )}


    </div>
  )
}

export default StaffProcessSurat