import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { useAuth } from '../contexts/AuthContext'
import { FileText, Eye, BellDot, LayoutDashboard, Download, Loader2 } from 'lucide-react'
import { api } from '../utils/api'
import { toast } from 'react-hot-toast' // Pastikan ini diimport

const SekretarisDashboard = () => {
  const [dashboardData, setDashboardData] = useState(null)
  const [loading, setLoading] = useState(true)
  const [isDownloading, setIsDownloading] = useState(false)
  const [downloadProgress, setDownloadProgress] = useState(0)
  const [downloadingSuratId, setDownloadingSuratId] = useState(null)
  const { user } = useAuth()

  useEffect(() => {
    fetchDashboardData()
  }, [])

  const fetchDashboardData = async () => {
    try {
      const response = await api.get('/dashboard')
      setDashboardData(response.data)
    } catch (error) {
      console.error('Error fetching dashboard data:', error)
    } finally {
      setLoading(false)
    }
  }

  const getStatusColor = (status) => {
    switch (status) {
      case 'pending':
        return 'bg-yellow-100 text-yellow-800'
      case 'processed':
        return 'bg-green-100 text-green-800'
      default:
        return 'bg-gray-100 text-gray-800'
    }
  }

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('id-ID', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    })
  }

  const handleDownloadPDF = async (suratId, nomorSurat) => {
    setIsDownloading(true)
    setDownloadingSuratId(suratId)
    setDownloadProgress(0)

    try {
      const response = await api.get(`/surat/${suratId}/pdf`, {
        responseType: 'blob',
        onDownloadProgress: (progressEvent) => {
          const total = progressEvent.total
          const current = progressEvent.loaded
          if (total) {
            const percentage = Math.round((current / total) * 100)
            setDownloadProgress(percentage)
          }
        }
      })

      // Create blob URL and download
      const url = window.URL.createObjectURL(new Blob([response.data]))
      const link = document.createElement('a')
      link.href = url
      link.setAttribute('download', `disposisi-${nomorSurat || suratId}.pdf`)
      document.body.appendChild(link)
      link.click()
      link.remove()
      window.URL.revokeObjectURL(url)

      toast.success('PDF berhasil diunduh!')

    } catch (err) {
      console.error('Error downloading PDF:', err)

      if (err.response) {
        const errorMessage = err.response.data?.error || 'Gagal mengunduh PDF'
        toast.error(errorMessage)
      } else if (err.request) {
        toast.error('Tidak ada respon dari server saat mengunduh PDF')
      } else {
        toast.error('Terjadi kesalahan saat mengunduh PDF')
      }
    } finally {
      setIsDownloading(false)
      setDownloadProgress(0)
      setDownloadingSuratId(null)
    }
  }

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div className='flex gap-x-2 items-center'>
          <div className="inline-flex items-center justify-center w-10 h-10 bg-gradient-to-bl from-blue-500 to-blue-300 rounded-lg shadow-lg">
            <LayoutDashboard className="w-6 h-6 text-white" />
          </div>
          <h1 className="text-2xl font-bold uppercase text-blue-500">Dashboard</h1>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white overflow-hidden shadow rounded-lg">
          <div className="p-5">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <FileText className="h-8 w-8 text-gray-600" />
              </div>
              <div className="ml-5 w-0 flex-1">
                <dl>
                  <dt className="text-sm font-medium text-gray-500 truncate">
                    Surat untuk Jabatan Anda
                  </dt>
                  <dd className="text-lg font-medium text-gray-900">
                    {dashboardData?.suratUntukJabatan?.length || 0}
                  </dd>
                </dl>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white overflow-hidden shadow rounded-lg">
          <div className="p-5">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <BellDot className="h-8 w-8 text-yellow-600" />
              </div>
              <div className="ml-5 w-0 flex-1">
                <dl>
                  <dt className="text-sm font-medium text-gray-500 truncate">
                    Notifikasi Belum Dibaca
                  </dt>
                  <dd className="text-lg font-medium text-gray-900">
                    {dashboardData?.unreadNotifications || 0}
                  </dd>
                </dl>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Recent Surat untuk Jabatan */}
      <div className="bg-white shadow rounded-lg">
        <div className="px-6 py-4 border-b border-gray-200">
          <h2 className="text-lg font-bold text-blue-500">Surat untuk Jabatan Anda</h2>
        </div>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Asal Instansi
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Keterangan
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Tanggal
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Status
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Aksi
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {dashboardData?.suratUntukJabatan?.slice(0, 5).map((surat) => (
                <tr key={surat.id}>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {surat.asal_instansi}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {surat.keterangan}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {formatDate(surat.created_at)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getStatusColor(surat.status)}`}>
                      {surat.status === 'pending' ? 'Menunggu' : 'Diproses'}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                    <div className="flex items-center space-x-3">
                      {/* Tombol Lihat */}
                      <Link
                        to={`/sekretaris-process/${surat.id}`}
                        className="text-blue-600 hover:text-blue-900 flex items-center space-x-1"
                      >
                        <Eye className="w-4 h-4" />
                        <span>Lihat</span>
                      </Link>
                      
                      {/* Tombol Download PDF */}
                      <button
                        onClick={() => handleDownloadPDF(surat.id, surat.nomor_surat)}
                        disabled={isDownloading && downloadingSuratId === surat.id}
                        className="text-green-600 hover:text-green-900 flex items-center space-x-1 disabled:opacity-50 disabled:cursor-not-allowed"
                        title="Download PDF"
                      >
                        {isDownloading && downloadingSuratId === surat.id ? (
                          <>
                            <Loader2 className="w-4 h-4 animate-spin" />
                            <span className="text-xs">
                              {downloadProgress > 0 ? `${downloadProgress}%` : 'Loading...'}
                            </span>
                          </>
                        ) : (
                          <>
                            <Download className="w-4 h-4" />
                            <span>PDF</span>
                          </>
                        )}
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
              
              {/* Empty State */}
              {(!dashboardData?.suratUntukJabatan || dashboardData.suratUntukJabatan.length === 0) && (
                <tr>
                  <td colSpan="5" className="px-6 py-8 text-center text-gray-500">
                    <div className="flex flex-col items-center space-y-2">
                      <FileText className="w-8 h-8 text-gray-400" />
                      <p>Tidak ada surat untuk jabatan Anda saat ini</p>
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
        
        {/* Show More Link */}
        {dashboardData?.suratUntukJabatan?.length > 5 && (
          <div className="px-6 py-4 border-t border-gray-200 text-center">
            <Link
              to="/surat-masuk"
              className="text-blue-600 hover:text-blue-900 text-sm font-medium"
            >
              Lihat Semua Surat ({dashboardData.suratUntukJabatan.length})
            </Link>
          </div>
        )}
      </div>      
    </div>
  )
}

export default SekretarisDashboard