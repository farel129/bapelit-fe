import { useParams, useNavigate } from 'react-router-dom'
import { Download, Eye, FileText, Save, User, UserCircle2, Send } from 'lucide-react'
import { useEffect, useState } from 'react'
import toast from 'react-hot-toast'

// Custom hooks
import { useSuratDetail } from '../hooks/useSuratDetail'
import { useSuratMasuk } from '../hooks/useSuratMasuk'

// Components
import ProcessingPopup from '../components/ProcessingPopup'
import SuratInfo from '../components/SuratInfo'
import PhotoGalleryModal from '../components/PhotoGalleryModal'
import { api } from '../utils/api'

const ForwardModal = ({ open, onClose, onSubmit, jabatanOptions, loading }) => {
  const [selected, setSelected] = useState([]);
  const [catatan, setCatatan] = useState('');

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/30">
      <div className="bg-white rounded-xl p-6 w-full max-w-md shadow-lg">
        <h2 className="font-bold text-blue-600 mb-4">Teruskan ke Bawahan (Bidang yang Sama)</h2>
        
        <label className="block mb-2 text-sm font-semibold">Pilih Jabatan Bawahan</label>
        
        {loading ? (
          <div className="w-full border rounded p-4 mb-4 text-center text-gray-500">
            Memuat daftar bawahan...
          </div>
        ) : jabatanOptions.length === 0 ? (
          <div className="w-full border rounded p-4 mb-4 text-center text-gray-500">
            Tidak ada bawahan dalam bidang yang sama
          </div>
        ) : (
          <select
            multiple
            className="w-full border rounded p-2 mb-4"
            value={selected}
            onChange={e => {
              const arr = Array.from(e.target.selectedOptions).map(opt => opt.value);
              setSelected(arr);
            }}
          >
            {jabatanOptions.map(jab => (
              <option key={jab} value={jab}>{jab}</option>
            ))}
          </select>
        )}
        
        <label className="block mb-2 text-sm font-semibold">Catatan (opsional)</label>
        <textarea
          className="w-full border rounded p-2 mb-4"
          rows={2}
          value={catatan}
          onChange={e => setCatatan(e.target.value)}
          placeholder="Tambahkan catatan jika diperlukan..."
        />
        
        <div className="flex justify-end gap-2">
          <button onClick={onClose} className="px-4 py-2 rounded bg-gray-200">
            Batal
          </button>
          <button
            onClick={() => onSubmit(selected, catatan)}
            className="px-4 py-2 rounded bg-blue-600 text-white disabled:bg-gray-400"
            disabled={selected.length === 0 || loading}
          >
            Teruskan
          </button>
        </div>
      </div>
    </div>
  );
};

const SendToJabatanModal = ({ open, onClose, onSubmit, jabatanOptions, loading, initialData }) => {
  const [sendData, setSendData] = useState({
    tujuan_jabatan: '',
    disposisi_kepada: ''
  });
  const [focusedField, setFocusedField] = useState(null);

  // Initialize data when modal opens
  useEffect(() => {
    if (open && initialData) {
      setSendData({
        tujuan_jabatan: initialData.tujuan_jabatan || '',
        disposisi_kepada: initialData.disposisi_kepada || ''
      });
    }
  }, [open, initialData]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setSendData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = () => {
    if (sendData.tujuan_jabatan && sendData.disposisi_kepada) {
      onSubmit(sendData);
    }
  };

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm">
      <div className="bg-white rounded-2xl p-8 w-full max-w-lg shadow-2xl border border-gray-200">
        <div className="flex items-center space-x-3 mb-6">
          <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-green-600 rounded-xl flex items-center justify-center">
            <Send className="w-6 h-6 text-white" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-gray-800">Kirim ke Jabatan Lain</h2>
            <p className="text-sm text-gray-500">Pilih tujuan jabatan dan disposisi</p>
          </div>
        </div>
        
        <div className="space-y-6">
          {/* Tujuan Jabatan */}
          <div className="group">
            <label className="flex items-center text-sm font-semibold text-slate-800 mb-3">
              <div className="w-8 h-8 bg-green-50 rounded-lg flex items-center justify-center mr-3">
                <User className="w-4 h-4 text-green-600" />
              </div>
              Tujuan Jabatan
            </label>
            <select
              name="tujuan_jabatan"
              value={sendData.tujuan_jabatan}
              onChange={handleChange}
              onFocus={() => setFocusedField('tujuan_jabatan')}
              onBlur={() => setFocusedField(null)}
              className={`w-full px-4 py-3 text-slate-800 bg-white border-2 rounded-xl transition-all duration-300 outline-none appearance-none cursor-pointer ${
                focusedField === 'tujuan_jabatan'
                  ? 'border-green-400 shadow-lg shadow-green-200/50 ring-4 ring-green-100/50'
                  : 'border-slate-200 hover:border-green-300'
              }`}
            >
              <option value="">Pilih tujuan jabatan...</option>
              {jabatanOptions.map((jabatan) => (
                <option key={jabatan} value={jabatan}>{jabatan}</option>
              ))}
            </select>
          </div>

          {/* Disposisi Kepada */}
          <div className="group">
            <label className="flex items-center text-sm font-semibold text-slate-800 mb-3">
              <div className="w-8 h-8 bg-green-50 rounded-lg flex items-center justify-center mr-3">
                <UserCircle2 className="w-4 h-4 text-green-600" />
              </div>
              Disposisi Kepada
            </label>
            <select
              name="disposisi_kepada"
              value={sendData.disposisi_kepada}
              onChange={handleChange}
              onFocus={() => setFocusedField('disposisi_kepada')}
              onBlur={() => setFocusedField(null)}
              className={`w-full px-4 py-3 text-slate-800 bg-white border-2 rounded-xl transition-all duration-300 outline-none appearance-none cursor-pointer ${
                focusedField === 'disposisi_kepada'
                  ? 'border-green-400 shadow-lg shadow-green-200/50 ring-4 ring-green-100/50'
                  : 'border-slate-200 hover:border-green-300'
              }`}
            >
              <option value="">Pilih disposisi kepada...</option>
              {jabatanOptions.map((jabatan) => (
                <option key={jabatan} value={jabatan}>{jabatan}</option>
              ))}
            </select>
          </div>
        </div>
        
        <div className="flex justify-end gap-3 mt-8 pt-6 border-t border-gray-200">
          <button 
            onClick={onClose} 
            className="px-6 py-2.5 text-gray-600 font-medium bg-gray-100 hover:bg-gray-200 rounded-xl transition-colors duration-200"
          >
            Batal
          </button>
          <button
            onClick={handleSubmit}
            disabled={!sendData.tujuan_jabatan || !sendData.disposisi_kepada || loading}
            className="inline-flex items-center px-6 py-2.5 font-medium rounded-xl transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800 text-white shadow-lg hover:shadow-xl"
          >
            {loading ? (
              <>
                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin mr-2"></div>
                Mengirim...
              </>
            ) : (
              <>
                <Send className="w-4 h-4 mr-2" />
                Kirim Surat
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};

const SekretarisProcessSurat = () => {
  const { id } = useParams()
  const navigate = useNavigate()
  const [showForward, setShowForward] = useState(false);
  const [forwardLoading, setForwardLoading] = useState(false);
  const [bawahanOptions, setBawahanOptions] = useState([]);
  const [loadingBawahan, setLoadingBawahan] = useState(false);
  const [userInfo, setUserInfo] = useState(null);
  const [showSendToJabatan, setShowSendToJabatan] = useState(false);
  const [sendToJabatanLoading, setSendToJabatanLoading] = useState(false);
  
  // State untuk melacak apakah surat sudah diproses atau diteruskan
  const [isActionTaken, setIsActionTaken] = useState(false);

  // Form data state - integrated from useSuratForm
  const [formData, setFormData] = useState({
    nomor_surat: '',
    perihal: '',
    tujuan_jabatan: '', // Tambahkan field ini
    disposisi_kepada: '',
    tindakan: [],
    sifat: '',
    catatan: ''
  })

  // Processing states - integrated from useSuratProcessing
  const [processing, setProcessing] = useState(false)
  const [showProcessingPopup, setShowProcessingPopup] = useState(false)
  const [processingComplete, setProcessingComplete] = useState(false)
  const [downloadProgress, setDownloadProgress] = useState(0)
  const [isDownloading, setIsDownloading] = useState(false)

  // Only remaining hook
  const { surat, loading, updateSuratStatus } = useSuratDetail(id)
  const { selectedPhotos, setSelectedPhotos } = useSuratMasuk()

  // Daftar jabatan yang tersedia
  const jabatanOptions = [
    'Sekretaris',
    'Kasubag Umum dan Kepegawaian',
    'Kasubag Keuangan',
    'Kabid Pendanaan, Pengendalian, dan Evaluasi',
    'Kabid Pemerintahan dan Pembangunan Manusia',
    'Kabid Perekonomian, Infrastruktur, dan Kewilayahan',
    'Kabid Penelitian dan Pengembangan'
  ]

  // Handler untuk mengubah form data
  const handleFormChange = (e) => {
    const { name, value } = e.target
    setFormData(prev => ({
      ...prev,
      [name]: value
    }))
  }

  // Processing handlers - integrated from useSuratProcessing
  const handleSubmit = async (formData) => {
    setProcessing(true)
    setShowProcessingPopup(true)
    setProcessingComplete(false)

    try {
      // Convert array back to string for backend compatibility if needed
      const dataToSend = {
        ...formData,
        tindakan: formData.tindakan.join(', ') // Join multiple actions with comma
      }
      
      await api.post(`/surat/${id}/process`, dataToSend)
      
      // Simulate processing delay for better UX
      await new Promise(resolve => setTimeout(resolve, 1500))
      
      setProcessingComplete(true)
      toast.success('Surat berhasil diproses!')
      
      // Update parent component status
      updateSuratStatus('processed')
      
      // Set action taken to true to disable the button
      setIsActionTaken(true)
      
    } catch (error) {
      console.error("Full error object:", error)
      setShowProcessingPopup(false)
      
      if (error.response) {
        console.error("Response data:", error.response.data)
        console.error("Response status:", error.response.status)
        toast.error(error.response.data?.error || 'Gagal memproses surat')
      } else if (error.request) {
        console.error("No response from server:", error.request)
        toast.error('Tidak ada respon dari server.')
      } else {
        console.error("Error saat setup request:", error.message)
        toast.error('Terjadi kesalahan saat mengirim data.')
      }
    } finally {
      setProcessing(false)
    }
  }

  const handleDownloadPDF = async () => {
    setIsDownloading(true)
    setDownloadProgress(0)

    try {
      const response = await api.get(`/surat/${id}/pdf`, {
        responseType: 'blob',
        onDownloadProgress: (progressEvent) => {
          const total = progressEvent.total
          const current = progressEvent.loaded
          const percentage = Math.round((current / total) * 100)
          setDownloadProgress(percentage)
        }
      })

      const url = window.URL.createObjectURL(new Blob([response.data]))
      const link = document.createElement('a')
      link.href = url
      link.setAttribute('download', `surat-${id}.pdf`)
      document.body.appendChild(link)
      link.click()
      link.remove()
      window.URL.revokeObjectURL(url)
      
      toast.success('PDF berhasil diunduh!')
      setShowProcessingPopup(false)
      
    } catch (error) {
      toast.error('Gagal mengunduh PDF')
    } finally {
      setIsDownloading(false)
      setDownloadProgress(0)
    }
  }

  const closePopup = () => {
    setShowProcessingPopup(false)
    setProcessingComplete(false)
    setDownloadProgress(0)
  }

  // Effect for form data initialization - integrated from useSuratForm
  useEffect(() => {
    if (surat) {
      // Handle tindakan conversion from string to array
      let tindakanArray = []
      if (surat.tindakan) {
        if (Array.isArray(surat.tindakan)) {
          tindakanArray = surat.tindakan
        } else if (typeof surat.tindakan === 'string') {
          // Split by comma and trim whitespace
          tindakanArray = surat.tindakan
            .split(',')
            .map(item => item.trim())
            .filter(item => item.length > 0)
        }
      }

      console.log("Tindakan yang akan diset:", tindakanArray)

      setFormData({
        nomor_surat: surat.nomor_surat || '',
        perihal: surat.perihal || '',
        tujuan_jabatan: surat.tujuan_jabatan || '', // Tambahkan ini
        disposisi_kepada: surat.disposisi_kepada || '',
        tindakan: tindakanArray,
        sifat: surat.sifat || '',
        catatan: surat.catatan || ''
      })
      
      // Cek apakah surat sudah diproses sebelumnya
      if (surat.status === 'processed' || surat.status === 'forwarded') {
        setIsActionTaken(true)
      }
    }
  }, [surat])

  useEffect(() => {
    const fetchBawahanOptions = async () => {
      setLoadingBawahan(true);
      try {
        const response = await api.get('/users/bawahan-bidang');
        // Extract jabatan unik dari response
        const jabatanList = [...new Set(response.data.data.map(user => user.jabatan))];
        setBawahanOptions(jabatanList);
        setUserInfo({ bidang: response.data.bidang });
      } catch (error) {
        console.error('Gagal mengambil data bawahan:', error);
        setBawahanOptions([]);
      } finally {
        setLoadingBawahan(false);
      }
    };

    fetchBawahanOptions();
  }, []);

  const onFormSubmit = (e) => {
    e.preventDefault()
    // Cek apakah action sudah diambil sebelumnya
    if (!isActionTaken) {
      handleSubmit(formData)
    }
  }

  const handleCancel = () => {
    navigate('/sekretaris')
  }

  const handleForward = async (selectedJabatan, catatan) => {
    setForwardLoading(true);
    try {
      const response = await api.post(`/surat/${id}/forward`, {
        bawahan_jabatan: selectedJabatan,
        catatan,
      });
      
      setShowForward(false);
      
      // Set action taken to true to disable the process button
      setIsActionTaken(true);
      
      const bidangInfo = response.data.bidang ? ` (Bidang: ${response.data.bidang})` : '';
      alert(`Surat berhasil diteruskan ke bawahan${bidangInfo}!`);
      
    } catch (err) {
      const errorMessage = err.response?.data?.error || 'Gagal meneruskan surat!';
      alert(errorMessage);
      console.error('Forward error:', err);
    } finally {
      setForwardLoading(false);
    }
  };

  const handleSendToJabatan = async (sendData) => {
    setSendToJabatanLoading(true);
    try {
      const response = await api.post(`/surat/${id}/send-to-jabatan`, {
        tujuan_jabatan: sendData.tujuan_jabatan,
        disposisi_kepada: sendData.disposisi_kepada
      });
      
      setShowSendToJabatan(false);
      
      // Set action taken to true to disable other buttons
      setIsActionTaken(true);
      
      toast.success(`Surat berhasil dikirim ke ${sendData.tujuan_jabatan}!`);
      
      // Navigate to /sekretaris after successful send
      navigate('/sekretaris');
            
    } catch (err) {
      const errorMessage = err.response?.data?.error || 'Gagal mengirim surat ke jabatan!';
      toast.error(errorMessage);
      console.error('Send to jabatan error:', err);
    } finally {
      setSendToJabatanLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    )
  }

  if (!surat) {
    return (
      <div className="text-center py-12">
        <p className="text-gray-500">Surat tidak ditemukan</p>
      </div>
    )
  }

  return (
    <div className="max-w-4xl mx-auto">
      {/* Processing Popup */}
      <ProcessingPopup
        showProcessingPopup={showProcessingPopup}
        processingComplete={processingComplete}
        isDownloading={isDownloading}
        downloadProgress={downloadProgress}
        onDownloadPDF={handleDownloadPDF}
        onClose={closePopup}
      />

      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex gap-x-3 items-center">
          <div className="inline-flex items-center justify-center w-10 h-10 bg-gradient-to-bl from-blue-500 to-blue-300 rounded-lg shadow-lg">
            <Eye className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-blue-500 uppercase">Verifikasi Surat</h1>
            {userInfo?.bidang && (
              <p className="text-sm text-gray-600">Bidang: {userInfo.bidang}</p>
            )}
          </div>
        </div>
        
        <div className="flex gap-2">
          {surat.status === 'processed' && (
            <button
              onClick={handleDownloadPDF}
              className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-gradient-to-bl from-blue-500 to-blue-300 hover:bg-gradient-to-bl hover:from-blue-500 hover:to-blue-500 cursor-pointer"
            >
              <Download className="w-4 h-4 mr-2" />
              Download PDF
            </button>
          )}
          
          <button
            onClick={() => setShowSendToJabatan(true)}
            className={`inline-flex items-center px-4 py-2 border text-sm font-medium rounded-md ${
              isActionTaken 
                ? 'border-gray-300 text-gray-400 bg-gray-100 cursor-not-allowed' 
                : 'border-green-500 text-green-600 bg-white hover:bg-green-50 cursor-pointer'
            }`}
            disabled={isActionTaken}
          >
            <Send className="w-4 h-4 mr-2" />
            Kirim ke Jabatan Lain
          </button>
          
          <button
            onClick={() => setShowForward(true)}
            className={`inline-flex items-center px-4 py-2 border text-sm font-medium rounded-md ${
              isActionTaken 
                ? 'border-gray-300 text-gray-400 bg-gray-100 cursor-not-allowed' 
                : 'border-blue-500 text-blue-600 bg-white hover:bg-blue-50 cursor-pointer'
            }`}
            disabled={loadingBawahan || isActionTaken}
          >
            {loadingBawahan ? 'Memuat...' : 'Teruskan ke Bawahan'}
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Surat Information */}
        <SuratInfo surat={surat} onOpenPhotos={setSelectedPhotos} />

        {/* Process Form - Fully Integrated */}
        <div className="max-w-4xl mx-auto">
          <div className="bg-white/80 backdrop-blur-sm shadow-xl rounded-2xl border border-white/20 overflow-hidden">
            {/* Header */}
            <div className="p-8">
              <div className="flex items-center space-x-3">
                <div className="">
                  <FileText className="w-8 h-8 text-blue-500" />
                </div>
                <div>
                  <h2 className="text-lg font-bold text-blue-500">Proses Surat</h2>
                  {isActionTaken && (
                    <p className="text-sm text-green-600 mt-1">✓ Surat sudah diproses atau diteruskan</p>
                  )}
                </div>
              </div>
            </div>
             
            {/* Form Content */}
            <div className="p-8">
              <form onSubmit={onFormSubmit} className="space-y-8">
                <div className="flex justify-end space-x-4 pt-6 border-t border-slate-200">
                  <button
                    type="button"
                    onClick={handleCancel}
                    className="px-8 py-3 text-slate-600 cursor-pointer font-semibold bg-slate-100 hover:bg-slate-200 rounded-xl transition-all duration-200 focus:ring-4 focus:ring-slate-300/30"
                  >
                    Batal
                  </button>
                  <button
                    type="submit"
                    disabled={processing || isActionTaken}
                    className={`inline-flex items-center px-8 py-3 font-semibold rounded-xl shadow-lg transition-all duration-200 focus:ring-4 ${
                      processing || isActionTaken
                        ? 'bg-gray-400 text-gray-200 cursor-not-allowed shadow-gray-300/25'
                        : 'bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white shadow-blue-500/25 hover:shadow-blue-500/40 cursor-pointer focus:ring-blue-500/30'
                    }`}
                  >
                    {processing ? (
                      <>
                        <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin mr-3"></div>
                        Memproses...
                      </>
                    ) : isActionTaken ? (
                      <>
                        <Save className="w-5 h-5 mr-3" />
                        Sudah Diproses
                      </>
                    ) : (
                      <>
                        <Save className="w-5 h-5 mr-3" />
                        Proses Surat
                      </>
                    )}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>

      {/* Modal Forward */}
      <ForwardModal
        open={showForward}
        onClose={() => setShowForward(false)}
        onSubmit={handleForward}
        jabatanOptions={bawahanOptions}
        loading={loadingBawahan || forwardLoading}
      />

      {/* Modal Send to Jabatan */}
      <SendToJabatanModal
        open={showSendToJabatan}
        onClose={() => setShowSendToJabatan(false)}
        onSubmit={handleSendToJabatan}
        jabatanOptions={jabatanOptions}
        loading={sendToJabatanLoading}
        initialData={formData}
      />

      {/* Photo Gallery Modal */}
      {selectedPhotos && (
        <PhotoGalleryModal
          photos={selectedPhotos.photos}
          suratInfo={selectedPhotos.info}
          onClose={() => setSelectedPhotos(null)}
        />
      )}
    </div>
  )
}

export default SekretarisProcessSurat